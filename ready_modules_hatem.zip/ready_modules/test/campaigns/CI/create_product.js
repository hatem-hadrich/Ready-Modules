var {selector} = require('../../globals.webdriverio.js');

module.exports = {
    createProduct: function (product_name_en, product_name_fr, product_picture, category_name) {
        scenario('Create new product', client => {
            test('should go to "Product Settings" page', () => client.waitForExistAndClick(selector.BO.Common.catalog_subtab));
            test('should click on "New Product" button', () => client.waitForExistAndClick(selector.BO.ProductsPage.new_product_button));
            test('should set the "Name" input in English language', () => client.waitAndSetValue(selector.BO.ProductPage.name_input_en, product_name_en + date_time));
            test('should select the "French language" from the select field', () => client.selectLanguage(selector.BO.ProductPage.language_button, selector.BO.ProductPage.language_option, 2));
            test('should set the "Name" input in French language', () => client.waitAndSetValue(selector.BO.ProductPage.name_input_fr, product_name_fr + date_time));
            test('should upload the product picture', () => client.uploadPicture(product_picture, "dz-hidden-input", selector.BO.ProductPage.picture));
            test('should set the "Quantity" input', () => client.setQuantity());
            test('should set the "Price" input', () => client.setPrice());
            if(category_name !== ''){
                test('should select the category', () => client.selectCategory(category_name + date_time));
            }
            test('should switch the product online', () => client.waitForExistAndClick(selector.BO.ProductPage.online_toggle));
            test('should verify the green validation', () => client.checkTextValue(selector.BO.ProductPage.validation_message, 'Settings updated.'));
        }, 'CI_clients/product_client');
        scenario('Check the product creation', client => {
            test('should go to "Product Settings" page', () => client.waitForExistAndClick(selector.BO.Common.products_subtab));
            test('should search the product by name', () => client.searchByName(product_name_en + date_time));
            test('should select the product name', () => client.waitForExistAndClick(selector.BO.ProductsPage.first_product));
            test('should check the existence of the product name ', () => client.checkAttributeValue(selector.BO.ProductPage.name_input_en, 'value', product_name_en + date_time));
            test('should generate the product picture URL', () => client.generatePictureURL());
            test('should verify the product picture', () => client.checkPicture());
            test('should verify the product quantity', () => client.checkAttributeValue(selector.BO.ProductPage.quantity_shortcut_input, 'value', '50'));
            test('should verify the product price ', () => client.checkAttributeValue(selector.BO.ProductPage.price_te_shortcut_input, 'value', '20.000000'));
        }, 'CI_clients/product_client');
    }
};