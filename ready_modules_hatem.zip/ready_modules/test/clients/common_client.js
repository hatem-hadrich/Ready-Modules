var {getClient} = require('../common.webdriverio.js');
var {selector} = require('../globals.webdriverio.js');
var path = require('path');
var buttonText;
var nbrModule;
var nbrBuilt;
var nbrTheme;

class CommonClient {
    constructor() {
        this.client = getClient();
    }

    //Tower functions
    clickOnManageMyStoreButton() {
        return this.client
            .waitForVisibleAndClick(selector.Tower.DashboardPage.manage_my_story_button, 180000)
            .switchWindow(1)
            .waitForVisible(selector.BO.Common.welcome_modal_later_button, 180000)
    }

    //BO functions
    takeScreenshot() {
        return this.client
            .saveScreenshot(`../screenshots/${this.client.desiredCapabilities.browserName}_exception_${global.date_time}.png`);
    }

    signInBO(selector) {
        return this.client.signinBO(selector);
    }

    signOutBO() {
        return this.client.signoutBO();
    }

    open() {
        return this.client.init().windowHandleMaximize();
    }

    close() {
        return this.client.end();
    };

    waitForExistAndClick(selector, timeout = 90000) {
        return this.client.waitForExistAndClick(selector, timeout);
    }

    waitForVisibleAndClick(selector, timeout = 90000) {
        return this.client.waitForVisibleAndClick(selector, timeout);
    }

    waitAndSetValue(selector, value) {
        return this.client.waitAndSetValue(selector, value)
    }

    switchTab(id) {
        return this.client.switchWindow(id)
    }

    closeWindow(id) {
        return this.client.closeWindow(id)
    }

    closeWelcomeOnboarding() {
        return this.client
            .waitForVisibleAndClick(selector.BO.Common.welcome_modal_later_button)
            .pause(5000)
    }

    checkTextValue(selector, message) {
        return this.client
            .waitForVisible(selector, 90000)
            .then(() => this.client.getText(selector))
            .then((text) => expect(text).to.be.equal(message));
    }

    checkAttributeValue(selector, attribute, value) {
        return this.client
            .waitForExist(selector, 90000)
            .then(() => this.client.getAttribute(selector, attribute))
            .then((text) => expect(text).to.be.equal(value));
    }

    waitForExist(selector, timeout = 3000) {
        return this.client.waitForExist(selector, timeout);
    }

    selectLanguage(selector, option, id) {
        return this.client
            .waitForExistAndClick(selector)
            .waitForExistAndClick(option.replace('%ID', id))
    }

    uploadPicture(picture, className, selector){
        return this.client
            .pause(5000)
            .execute(function (className) {
                document.getElementsByClassName(className).style = '';
            })
            .chooseFile(selector, path.join(__dirname, '..', 'datas', picture))
    }

    goToSubtabMenuPage(menuSelector, selector) {
        return this.client
            .waitForExist(menuSelector, 90000)
            .moveToObject(menuSelector)
            .waitForExistAndClick(selector)
    }

    goToModulesPage() {
        return this.client
            .waitForExistAndClick(selector.BO.Common.modules_subtub)
            .waitForExist(selector.BO.ModulesPage.modules_search_results, 90000)
    }

    searchModule(moduleName) {
        return this.client
            .waitAndSetValue(selector.BO.ModulesPage.modules_search_input, moduleName)
            .waitForExistAndClick(selector.BO.ModulesPage.modules_search_button)
    }

    getInstalledModulesNumber() {
        return this.client
            .getText(selector.BO.ModulesPage.installed_modules_number_span).then(function (text) {
                nbrModule = parseInt(text[0]);
            })
            .getText(selector.BO.ModulesPage.installed_built_modules_number_span).then(function (text) {
                nbrBuilt = parseInt(text[0]);
            })
            .getText(selector.BO.ModulesPage.installed_theme_modules_number_span).then(function (text) {
                nbrTheme = parseInt(text[0]);
            })
    }

    getModuleButtonName() {
        if (nbrModule === 1)
            return this.client.getText(selector.BO.ModulesPage.action_module_installed_button).then(function (text) {
                buttonText = text;
            })
        else if (nbrBuilt ===1)
            return this.client.getText(selector.BO.ModulesPage.action_module_built_button).then(function (text) {
                buttonText = text;
            })
        else return this.client.getText(selector.BO.ModulesPage.action_module_theme_button).then(function (text) {
                buttonText = text;
            })
    }

    clickConfigureModuleButton(module_tech_name) {
        if (buttonText === "CONFIGURE")
            return this.client
                .waitForExistAndClick(selector.BO.ModulesPage.configure_module_button.replace("%module_tech_name", module_tech_name))
        else return this.client
            .waitForExistAndClick(selector.BO.ModulesPage.actions_module_dropdown)
            .waitForExistAndClick(selector.BO.ModulesPage.configure_module_button.replace("%module_tech_name", module_tech_name))
    }

    clickEnableModuleButton(module_tech_name) {
        if (buttonText === "ENABLE")
            return this.client
                .click(selector.BO.ModulesPage.enable_module_button.replace("%module_tech_name", module_tech_name))
                .waitForExist(selector.BO.Common.close_validation_button, 90000)
        else return this.client
            .waitForExist(selector.BO.ModulesPage.actions_module_dropdown, 90000)
            .click(selector.BO.ModulesPage.actions_module_dropdown)
            .waitForExist(selector.BO.ModulesPage.enable_module_button.replace("%module_tech_name", module_tech_name), 90000)
            .click(selector.BO.ModulesPage.enable_module_button.replace("%module_tech_name", module_tech_name))
            .waitForExist(selector.BO.Common.close_validation_button, 90000)
    }

    clickDisableModuleButton(module_tech_name) {
        if (buttonText === "DISABLE")
            return this.client
                .click(selector.BO.ModulesPage.disable_module_button.replace("%module_tech_name", module_tech_name))
                .waitForVisible(selector.BO.ModulesPage.disable_module_confirm_button, 90000)
                .click(selector.BO.ModulesPage.disable_module_confirm_button)
                .waitForExist(selector.BO.Common.close_validation_button, 90000)
        else return this.client
            .waitForExist(selector.BO.ModulesPage.actions_module_dropdown, 90000)
            .click(selector.BO.ModulesPage.actions_module_dropdown)
            .waitForExist(selector.BO.ModulesPage.disable_module_button.replace("%module_tech_name", module_tech_name), 90000)
            .click(selector.BO.ModulesPage.disable_module_button.replace("%module_tech_name", module_tech_name))
            .waitForVisible(selector.BO.Common.disable_module_confirm_button, 90000)
            .click(selector.BO.ModulesPage.disable_module_confirm_button)
            .waitForExist(selector.BO.Common.close_validation_button, 90000)
    }

    goToOrdersPage() {
        return this.client
            .click(selector.BO.Common.orders_settings_button)
            .waitForExist(selector.BO.OrdersPage.add_new_order_button, 90000)
    }

    searchOrderById() {
        return this.client
            .setValue(selector.BO.OrdersPage.id_input, global.order_id)
            .click(selector.BO.OrdersPage.search_button)
    }

    goToOrderPage() {
        return this.client
            .waitForExist(selector.BO.OrdersPage.first_order_select, 9000)
            .click(selector.BO.OrdersPage.first_order_select)
    }

    changeOrderStatus(status) {
        return this.client
            .click(selector.BO.OrderPage.order_status_dropdown)
            .click(selector.BO.OrderPage.order_status_from_list.replace("%s", status))
            .click(selector.BO.OrderPage.update_status_button)
            .pause(2000)
    }

    //FO functions
    openFO(id) {
        return this.client
            .waitForExistAndClick(selector.BO.Common.shopname_link)
            .switchWindow(id)

    }

    signInFO(selector) {
        return this.client
            .signinFO(selector);
    }

    signOutFO(selector) {
        return this.client.signoutFO(selector);
    }

    openShop() {
        return this.client
            .url('http://' + URL)
            .waitForExist(selector.FO.HomePage.logo_home_page)
    }

    searchProduct(product_name) {
        return this.client
            .waitAndSetValue(selector.FO.HomePage.search_input, product_name + date_time)
            .waitForExistAndClick(selector.FO.HomePage.search_icon)
    }

    selectFirstProduct() {
        return this.client
            .click(selector.FO.HomePage.logo_home_page)
            .waitForExist(selector.FO.HomePage.first_product_home_page, 90000)
            .click(selector.FO.HomePage.first_product_home_page)
            .pause(2000)
    }

    clickAddToCartButton() {
        return this.client
            .waitForExist(selector.FO.ProductPage.add_to_cart_button, 90000)
            .click(selector.FO.ProductPage.add_to_cart_button)
    }

    clickContinueShoppingButton() {
        return this.client
            .pause(2000)
            .waitForExist(selector.FO.ProductPage.continue_shopping_button, 90000)
            .click(selector.FO.ProductPage.continue_shopping_button)
    }

    goToCartPage() {
        return this.client
            .pause(2000)
            .waitForExist(selector.FO.HomePage.cart_button)
            .click(selector.FO.HomePage.cart_button)
            .waitForExist(selector.FO.CartPage.proceed_to_checkout_button, 90000)
    }

    clickProceedCheckoutButton() {
        return this.client
            .click(selector.FO.CartPage.proceed_to_checkout_button)
            .waitForExist(selector.FO.CheckoutPage.PersonalInformationSection.header, 90000)
    }

    fillPersonnelInformationForm() {
        return this.client
            .click(selector.FO.CheckoutPage.PersonalInformationSection.order_as_a_guest_button)
            .click(selector.FO.CheckoutPage.PersonalInformationSection.social_title_mr_radio_button)
            .setValue(selector.FO.CheckoutPage.PersonalInformationSection.first_name_input, 'John')
            .setValue(selector.FO.CheckoutPage.PersonalInformationSection.last_name_input, 'Doe')
            .setValue(selector.FO.CheckoutPage.PersonalInformationSection.email_guest_input, 'pub@prestashop.com')
            //.click(selector.FO.CheckoutPage.PersonalInformationSection.customer_privacy_checkbox)
            .scroll(selector.FO.CheckoutPage.PersonalInformationSection.continue_guest_personal_information_button, 90000)
            .click(selector.FO.CheckoutPage.PersonalInformationSection.continue_guest_personal_information_button)
    }

    fillAddressForm() {
        return this.client
            .setValue(selector.FO.CheckoutPage.AddressesSection.address_input, '12 Rue d\'Amsterdam')
            .setValue(selector.FO.CheckoutPage.AddressesSection.postcode_input, '75009')
            .setValue(selector.FO.CheckoutPage.AddressesSection.city_input, 'Paris')
            .click(selector.FO.CheckoutPage.AddressesSection.country_checkbox + '/option[2]')
            .scroll(selector.FO.CheckoutPage.AddressesSection.continue_addresses_button)
            .click(selector.FO.CheckoutPage.AddressesSection.continue_addresses_button)
    }

    fillShippingForm() {
        return this.client
            .scroll(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button)
            .click(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button)
    }

    fillPaymentForm() {
        return this.client
            .click(selector.FO.CheckoutPage.PaymentSection.pay_by_check_radio_button)
            .click(selector.FO.CheckoutPage.PaymentSection.terms_of_service_checkbox)
            .scroll(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
            .click(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
    }

    getId(id) {
        return this.client
            .url()
            .then((res) => {
                var current_url = res.value;
                var temp1 = current_url.split(id + '=');
                var temp2 = temp1[1].split("&");
                global.id = temp2[0];
            })
    }
}
module.exports = CommonClient;