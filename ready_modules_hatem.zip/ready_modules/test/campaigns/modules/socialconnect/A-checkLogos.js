global.social_connect = ["facebook", "twitter", "amazon", "google", "pinterest", "yahoo", "paypal", "linkedin", "microsoft", "foursquare", "github", "disqus", "dropbox", "wordpress", "tumblr", "vkontakte"];
scenario('Check all social network button in the Front Office', client => {
    test('should open browser', () => client.open());
    test('should go to the Front Office', () => client.openShop());
    for (let i = 0; i < (global.social_connect.length); i++) {
        test('should check ' + social_connect[i] + ' button at the top of the page', () => client.findFirstLogos(global.social_connect[i]));
        test('should check ' + social_connect[i] + ' button near the connection button', () => client.findSecondLogos(global.social_connect[i]));
        test('should check ' + social_connect[i] + ' button at the bottom of the page', () => client.findThirdLogos(global.social_connect[i]));
    }
}, "modules_clients/social_connect/checkLogos_client", true);