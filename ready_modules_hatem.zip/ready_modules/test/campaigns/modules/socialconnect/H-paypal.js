// @TODO:fix connecting with paypal in FO (error client_id ou redirect_uri incorrect)
const { selector } = require('../../../globals.webdriverio.js');

scenario('Test module : "Social Connect" - PAYPAL', () => {
    scenario('Configure paypal in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on paypal menu tab', () => client.ClickOnConfigurationAccountMenu(9));
        test('should configuration page is shown', () => client.waitForConfigurePage('paypal'));
        test('should click on paypal developers link', () => client.clickOnDevelopersLink('paypal'));
        test('should click on log into dashboard button', () => client.clickOnLogIntoDashboardButton());
        test('should log in with paypal account', () => client.fillPaypalSignInForm());
        test('should access to the application', () => client.accessToApplication());
        test('should click on show secret button', () => client.clickOnShowSecretButton());
        test('should click on show return url button', () => client.clickOnReturnUrlButton());
        test('should edit return url', () => client.setReturnUrl());
        test('should click on show return url button', () => client.clickOnAdvancedOptionsButton());
        test('should edit privacy policy url', () => client.setPrivacyPolicyUrl());
        test('should edit user agreement url', () => client.setUserAgreementUrl());
        test('should click on save button', () => client.clickOnSaveButton());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/paypal_client", true);
    scenario('Connect with paypal account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on paypal button', () => client.clickOnPaypalButton('paypal'));
        test('should connecting with paypal account', () => client.connectingPaypalAccount());
        test('should check the connection', () => client.checkConnections('Presto Tests'));
    }, "modules_clients/social_connect/paypal_client", true);
    scenario('Check paypal customer in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Customer settings" page', () => client.goToSubtabMenuPage(selector.BO.Common.customer_subtab, selector.BO.Common.customer_settings_subtab));
        test('should filter the list of customers by email', () => client.filterListCustomerByAddressEmail("prestotests+paypal@gmail.com"));
        test('should click on search button', () => client.clickOnSearchButton());
        test('should check paypal customer', () => client.checkCutomer('paypal'));
    }, "modules_clients/social_connect/paypal_client", true);
    scenario('Buy product with paypal account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on paypal button', () => client.clickOnConnectAccountButton('paypal'));
        test('should connecting with paypal account', () => client.connectingPaypalAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/paypal_client", true);
}, "modules_clients/social_connect/paypal_client", true);