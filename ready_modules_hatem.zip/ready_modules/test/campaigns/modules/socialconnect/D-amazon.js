// @TODO:fix connecting with amazon in FO
const globals = require('../../../globals.webdriverio.js');

scenario('Test module "Social Connect" - AMAZON', () => {
    scenario('Configure amazon in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(globals.selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on amazon menu tab', () => client.ClickOnConfigurationAccountMenu(6));
        test('should configuration page is shown', () => client.waitForConfigurePage('amazon'));
        test('should click on "amazon developers" link', () => client.clickOnDevelopersLink('amazon'));
        test('should click on "sign in to the app console" button', () => client.waitForExistAndClick(globals.external.FO.Amazon.signin_to_console_button));
        test('should login with amazon account', () => client.fillAmazonSignInForm());
        test('should access to the application', () => client.accessToApplication());
        test('should click on "Edit" button', () => client.waitForExistAndClick(globals.external.FO.Amazon.Application.edit_button));
        test('should set application url', () => client.setApplication());
        test('should click on "Edit" button', () => client.waitForExistAndClick(globals.external.FO.Amazon.WebsiteSettings.edit_button));
        test('should set website urls', () => client.setWebsite());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/amazon_client", true);
    scenario('Connect with twitter account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on amazon button', () => client.clickOnAmazonButton('amazon'));
        test('should connecting with amazon account', () => client.connectingAmazonAccount());
        test('should check the connection', () => client.checkConnections('prestotests prestotests'));
    }, "modules_clients/social_connect/amazon_client", true);
    scenario('Buy product with twitter account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on twitter button', () => client.clickOnConnectAccountButton('amazon'));
        test('should connecting with twitter account', () => client.connectingAmazonAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/twitter_client", true);
}, "modules_clients/social_connect/amazon_client", true);