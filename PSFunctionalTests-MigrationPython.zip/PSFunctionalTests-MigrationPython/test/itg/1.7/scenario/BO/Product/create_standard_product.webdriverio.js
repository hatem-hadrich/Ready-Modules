'use strict';
var should = require('should');
var common = require('../../../common.webdriverio');
var globals = require('../../../globals.webdriverio.js');
var standard_product = require('../../../datas/product_datas');

var path = require('path');
var newFile = path.join(__dirname, '../../..', 'datas', 'bleue.jpg');

function getPicture(name) {
    return path.join(__dirname, '../../..', 'datas', name);
}


describe('Add new standard product', function () {
    common.initMocha.call(this);

    before(function (done) {
        this.selector = globals.selector;
        this.client.call(done);
    });
    process.on('uncaughtException', common.take_screenshot);
    process.on('ReferenceError', common.take_screenshot);
    after(common.after);

    function uploadFile(browser, fileSelector, fileName, done) {
        browser
            .execute(function () {
                document.getElementsByClassName("dz-hidden-input").style = "";
            })
            .chooseFile(fileSelector, getPicture(fileName))
            .getAttribute(fileSelector, "data-id").then(function (text) {
            global.image_data_id = text;
        })
            .pause(2000)
            .call(done);
    }

    describe('Log in in Back Office', function (done) {
        it('should log in successfully in BO', function (done) {
            global.fctname = this.test.title;
            this.client
                .signinBO()
                .waitForExist(this.selector.menu, 90000)
                .call(done);
        });
    });

    describe('Create new product', function (done) {
        it("should go to the products page", function (done) {
            global.fctname = this.test.title;
            this.client
                .click(this.selector.ProductPage.products_subtab)
                .waitForExist(this.selector.ProductPage.new_product_button, 120000)
                .call(done);
        });

        it("should click on add new product button", function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.new_product_button, 120000)
                .click(this.selector.ProductPage.new_product_button)
                .waitForExist(this.selector.ProductPage.product_name_input, 60000)
                .call(done);
        });

        it('should select the product combinations', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_combinations, 90000)
                .click(this.selector.ProductPage.product_combinations)
                .pause(3000)
                .call(done);
        });

        it('should enter the product name', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_name_input, 90000)
                .setValue(this.selector.ProductPage.product_name_input, standard_product.standard.name + product_id)
                .pause(6000)
                .call(done);
        });

        it('should enter the product summary', function (done) {
            global.fctname = this.test.title;
            this.client
                .frame(this.selector.summary, function (err, result) {
                    if (err) console.log(err);
                })
                .setValue("#tinymce", standard_product.common.resume)
                .frameParent()
                .pause(2000)
                .call(done);
        });

        it('should enter the product description', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.tab_description, 90000)
                .click(this.selector.ProductPage.tab_description)
                .frame(this.selector.description, function (err, result) {
                    if (err) console.log(err);
                })
                .setValue("#tinymce", standard_product.common.desc)
                .frameParent()
                .pause(2000)
                .call(done);
        });

        it('should upload the picture one of product', function (done) {
            global.fctname = this.test.title;
            this.client
                .execute(function () {
                    document.getElementsByClassName("dz-hidden-input").style = "";
                })
                .chooseFile(this.selector.ProductPage.picture, getPicture('1.png'))
                .waitForExist(this.selector.ProductPage.picture_cover, 90000)
                .getAttribute(this.selector.ProductPage.picture, "data-id").then(function (text) {
                global.image_data_id = text;
            })
                .pause(2000)
                .call(done);
        });

        it('should upload the picture two of product', function (done) {
            global.fctname = this.test.title;
            uploadFile(this.client, this.selector.ProductPage.picture, '2.jpg', done);
        });

        it('should upload the picture three of product', function (done) {
            global.fctname = this.test.title;
            uploadFile(this.client, this.selector.ProductPage.picture, '3.jpg', done);
        });

        it('should upload the picture fore of product', function (done) {
            global.fctname = this.test.title;
            uploadFile(this.client, this.selector.ProductPage.picture, '4.gif', done);
        });

        it('should upload the picture five of product', function (done) {
            global.fctname = this.test.title;
            uploadFile(this.client, this.selector.ProductPage.picture, '5.jpg', done);
        });

        it('should upload the picture six of product', function (done) {
            global.fctname = this.test.title;
            uploadFile(this.client, this.selector.ProductPage.picture, '6.jpg', done);
        });

        it('should click on create category button', function (done) {
            this.client
                .scroll(0, 600)
                .waitForExist(this.selector.ProductPage.product_create_category_btn, 90000)
                .click(this.selector.ProductPage.product_create_category_btn)
                .pause(2000)
                .call(done);
        });

        it('should enter the category name', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_category_name_input, 90000)
                .setValue(this.selector.ProductPage.product_category_name_input, standard_product.standard.new_category_name + product_id)
                .pause(2000)
                .call(done);
        });

        it('should click on create category button', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(0, 600)
                .waitForExist(this.selector.ProductPage.category_create_btn, 90000)
                .click(this.selector.ProductPage.category_create_btn)
                .pause(2000)
                .call(done);
        });

        it('should click on add brand button', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_brand_btn, 90000)
                .click(this.selector.ProductPage.product_add_brand_btn)
                .pause(2000)
                .call(done);
        });

        it('should select a brand', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_brand_select, 90000)
                .click(this.selector.ProductPage.product_brand_select)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.product_brand_select_option, 90000)
                .click(this.selector.ProductPage.product_brand_select_option)
                .pause(2000)
                .call(done);
        });

        it('should click on add related product button', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.add_related_product_btn, 90000)
                .click(this.selector.ProductPage.add_related_product_btn)
                .pause(2000)
                .call(done);
        });

        it('should add a related product', function (done) {
            var search_products = standard_product.common.search_related_products.split('//');
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.search_add_related_product_input, 90000)
                .setValue(this.selector.ProductPage.search_add_related_product_input, search_products[0])
                .waitForExist(this.selector.ProductPage.related_product_item, 90000)
                .click(this.selector.ProductPage.related_product_item)
                .pause(2000)
                .setValue(this.selector.ProductPage.search_add_related_product_input, search_products[1])
                .waitForExist(this.selector.ProductPage.related_product_item, 90000)
                .click(this.selector.ProductPage.related_product_item)
                .pause(2000)
                .call(done);
        });

        it('should add feature height', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select.replace('%I', 1), 90000)
                .click(this.selector.ProductPage.feature_select.replace('%I', 1))
                .waitForExist(this.selector.ProductPage.select_feature_created, 90000)
                .setValue(this.selector.ProductPage.select_feature_created, 'Height')
                .waitForExist(this.selector.ProductPage.result_feature_select.replace('%ID', 0), 90000)
                .click(this.selector.ProductPage.result_feature_select.replace('%ID', 0))
                .waitForExist(this.selector.ProductPage.feature_custom_value.replace('%S', 0), 90000)
                .setValue(this.selector.ProductPage.feature_custom_value.replace('%S', 0), standard_product.standard.features.feature1.custom_value)
                .pause(2000)
                .call(done);
        });

        it('should add feature width', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 2), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 2))
                .waitForExist(this.selector.ProductPage.select_feature_created, 90000)
                .setValue(this.selector.ProductPage.select_feature_created, 'Width')
                .waitForExist(this.selector.ProductPage.result_feature_select.replace('%ID', 1), 90000)
                .click(this.selector.ProductPage.result_feature_select.replace('%ID', 1))
                .waitForExist(this.selector.ProductPage.feature_custom_value.replace('%S', 1), 90000)
                .setValue(this.selector.ProductPage.feature_custom_value.replace('%S', 1), standard_product.standard.features.feature2.custom_value)
                .pause(2000)
                .call(done);
        });

        it('should add feature depth', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 3), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 3))
                .waitForExist(this.selector.ProductPage.select_feature_created, 90000)
                .setValue(this.selector.ProductPage.select_feature_created, 'Depth')
                .waitForExist(this.selector.ProductPage.result_feature_select.replace('%ID', 2), 90000)
                .click(this.selector.ProductPage.result_feature_select.replace('%ID', 2))
                .waitForExist(this.selector.ProductPage.feature_custom_value.replace('%S', 2), 90000)
                .setValue(this.selector.ProductPage.feature_custom_value.replace('%S', 2), standard_product.standard.features.feature3.custom_value)
                .pause(2000)
                .call(done);
        });

        it('should add feature weight', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 4), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 4))
                .waitForExist(this.selector.ProductPage.select_feature_created, 90000)
                .setValue(this.selector.ProductPage.select_feature_created, 'Weight')
                .waitForExist(this.selector.ProductPage.result_feature_select.replace('%ID', 3), 90000)
                .click(this.selector.ProductPage.result_feature_select.replace('%ID', 3))
                .waitForExist(this.selector.ProductPage.feature_custom_value.replace('%S', 3), 90000)
                .setValue(this.selector.ProductPage.feature_custom_value.replace('%S', 3), standard_product.standard.features.feature4.custom_value)
                .pause(2000)
                .call(done);
        });

        it('should add feature compositions', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(0, 600)
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 5), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 5))
                .waitForExist(this.selector.ProductPage.select_feature_created, 90000)
                .setValue(this.selector.ProductPage.select_feature_created, 'Compositions')
                .waitForExist(this.selector.ProductPage.result_feature_select.replace('%ID', 4), 90000)
                .click(this.selector.ProductPage.result_feature_select.replace('%ID', 4))
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_value.replace('%S', 4), 90000)
                .click(this.selector.ProductPage.feature_value.replace('%S', 4))
                .waitForExist(this.selector.ProductPage.feature_option_value.replace('%S', 4).replace('%I', 10), 90000)
                .click(this.selector.ProductPage.feature_option_value.replace('%S', 4).replace('%I', 10))
                .pause(2000)
                .call(done);
        });

        it('should add feature styles', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 6), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 6))
                .waitForExist(this.selector.ProductPage.feature_select_option.replace('%S', 5).replace('%I', 7), 90000)
                .click(this.selector.ProductPage.feature_select_option.replace('%S', 5).replace('%I', 7))
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_value.replace('%S', 5), 90000)
                .click(this.selector.ProductPage.feature_value.replace('%S', 5))
                .waitForExist(this.selector.ProductPage.feature_option_value.replace('%S', 5).replace('%I', 3), 90000)
                .click(this.selector.ProductPage.feature_option_value.replace('%S', 5).replace('%I', 3))
                .pause(2000)
                .call(done);
        });

        it('should add feature properties', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_add_feature_btn, 90000)
                .click(this.selector.ProductPage.product_add_feature_btn)
                .pause(2000)
                .scroll(0, 600)
                .waitForExist(this.selector.ProductPage.feature_select2.replace('%I', 7), 90000)
                .click(this.selector.ProductPage.feature_select2.replace('%I', 7))
                .waitForExist(this.selector.ProductPage.feature_select_option.replace('%S', 6).replace('%I', 8), 90000)
                .click(this.selector.ProductPage.feature_select_option.replace('%S', 6).replace('%I', 8))
                .pause(2000)
                .waitForExist(this.selector.ProductPage.feature_value.replace('%S', 6), 90000)
                .click(this.selector.ProductPage.feature_value.replace('%S', 6))
                .waitForExist(this.selector.ProductPage.feature_option_value.replace('%S', 6).replace('%I', 2), 90000)
                .click(this.selector.ProductPage.feature_option_value.replace('%S', 6).replace('%I', 2))
                .pause(2000)
                .call(done);
        });

        it('should enter the product price tax excluded', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(800, 0)
                .waitForExist(this.selector.ProductPage.priceTE_shortcut, 60000)
                .click(this.selector.ProductPage.priceTE_shortcut)
                .pause(2000)
                .setValue(this.selector.ProductPage.priceTE_shortcut, standard_product.common.priceTE)
                .call(done);
        });

        it('should enter the product reference', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_reference, 60000)
                .click(this.selector.ProductPage.product_reference)
                .setValue(this.selector.ProductPage.product_reference, standard_product.common.product_reference)
                .call(done);
        });

        it('should select product online', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_online_toggle, 60000)
                .click(this.selector.ProductPage.product_online_toggle)
                .pause(2000)
                .call(done);
        });

        it('should save and stay in the product page', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.save_product_btn, 60000)
                .click(this.selector.ProductPage.save_product_btn)
                .pause(3000)
                .call(done);
        });
    });

    describe('Create product combinations ', function (done) {
        it('should go to the product combinations form', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.product_combinations_tab, 60000)
                .click(this.selector.ProductPage.product_combinations_tab)
                .call(done);
        });

        it('should create first variation', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.combination_size_s, 60000)
                .click(this.selector.ProductPage.combination_size_s)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.combination_color_gray, 60000)
                .click(this.selector.ProductPage.combination_color_gray)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.combination_generate_button, 60000)
                .click(this.selector.ProductPage.combination_generate_button)
                .pause(2000)
                .call(done);
        });

        it('should create second variation', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.combination_size_m, 60000)
                .click(this.selector.ProductPage.combination_size_m)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.combination_color_beige, 60000)
                .click(this.selector.ProductPage.combination_color_beige)
                .pause(2000)
                .waitForExist(this.selector.ProductPage.combination_generate_button, 60000)
                .click(this.selector.ProductPage.combination_generate_button)
                .pause(2000)
                .call(done);
        });

        it('should click on edit the first combination ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.ProductPage.combination_panel.replace('%NUMBER', 1), 60000)
                .getAttribute(this.selector.ProductPage.combination_panel.replace('%NUMBER', 1), "data").then(function (text) {
                global.combination_id = text;
            })
                .waitForExist(this.selector.combination_edit_button.replace('%ID', combination_id), 60000)
                .click(this.selector.combination_edit_button.replace('%ID', combination_id))
                .pause(2000)
                .call(done);
        });

        it('should edit the first combination', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_first_details_qty, 60000)
                .click(this.selector.combination_first_details_qty)
                .pause(2000)
                .setValue(this.selector.combination_first_details_qty, standard_product.standard.variations.variation1.quantity)
                .waitForExist(this.selector.combination_first_details_ref, 60000)
                .click(this.selector.combination_first_details_ref)
                .pause(2000)
                .setValue(this.selector.combination_first_details_ref, standard_product.standard.variations.variation1.ref)
                .waitForExist(this.selector.combination_first_details_minimal_quantity, 60000)
                .click(this.selector.combination_first_details_minimal_quantity)
                .pause(2000)
                .setValue(this.selector.combination_first_details_minimal_quantity, standard_product.standard.variations.variation1.minimal_quantity)
                .waitForExist(this.selector.combination_first_details_available_date, 60000)
                .click(this.selector.combination_first_details_available_date)
                .pause(2000)
                .setValue(this.selector.combination_first_details_available_date, standard_product.standard.variations.variation1.available_date)
                .waitForExist(this.selector.combination_first_details_wholesale, 60000)
                .click(this.selector.combination_first_details_wholesale)
                .pause(2000)
                .setValue(this.selector.combination_first_details_wholesale, standard_product.standard.variations.variation1.wholesale)
                .waitForExist(this.selector.combination_first_details_priceTI, 60000)
                .click(this.selector.combination_first_details_priceTI)
                .pause(2000)
                .setValue(this.selector.combination_first_details_priceTI, standard_product.standard.variations.variation1.priceTI)
                .waitForExist(this.selector.combination_first_details_unity, 60000)
                .click(this.selector.combination_first_details_unity)
                .pause(2000)
                .setValue(this.selector.combination_first_details_unity, standard_product.standard.variations.variation1.unity)
                .waitForExist(this.selector.combination_first_details_weight, 60000)
                .click(this.selector.combination_first_details_weight)
                .pause(2000)
                .setValue(this.selector.combination_first_details_weight, standard_product.standard.variations.variation1.weight)
                .waitForExist(this.selector.combination_first_details_ISBN_code, 60000)
                .click(this.selector.combination_first_details_ISBN_code)
                .pause(2000)
                .setValue(this.selector.combination_first_details_ISBN_code, standard_product.standard.variations.variation1.isbn)
                .waitForExist(this.selector.combination_first_details_EAN13, 60000)
                .click(this.selector.combination_first_details_EAN13)
                .pause(2000)
                .setValue(this.selector.combination_first_details_EAN13, standard_product.standard.variations.variation1.ean13)
                .waitForExist(this.selector.combination_first_details_UPC, 60000)
                .click(this.selector.combination_first_details_UPC)
                .pause(2000)
                .setValue(this.selector.combination_first_details_UPC, standard_product.standard.variations.variation1.upc)
                .call(done);
        });

        it('should click on back to product button', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_first_details_back_to_product_btn, 60000)
                .click(this.selector.combination_first_details_back_to_product_btn)
                .pause(3000)
                .call(done);
        });

        it('should click on edit the second combination ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_edit_second_variation, 60000)
                .click(this.selector.combination_edit_second_variation)
                .pause(2000)
                .call(done);
        });

        it('should edit the second combination', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_second_details_qty, 60000)
                .click(this.selector.combination_second_details_qty)
                .pause(2000)
                .setValue(this.selector.combination_second_details_qty, standard_product.standard.variations.variation2.quantity)
                .waitForExist(this.selector.combination_second_details_ref, 60000)
                .click(this.selector.combination_second_details_ref)
                .pause(2000)
                .setValue(this.selector.combination_second_details_ref, standard_product.standard.variations.variation2.ref)
                .waitForExist(this.selector.combination_second_details_minimal_quantity, 60000)
                .click(this.selector.combination_second_details_minimal_quantity)
                .pause(2000)
                .setValue(this.selector.combination_second_details_minimal_quantity, standard_product.standard.variations.variation2.minimal_quantity)
                .waitForExist(this.selector.combination_second_details_available_date, 60000)
                .click(this.selector.combination_second_details_available_date)
                .pause(2000)
                .setValue(this.selector.combination_second_details_available_date, standard_product.standard.variations.variation2.available_date)
                .waitForExist(this.selector.combination_second_details_wholesale, 60000)
                .click(this.selector.combination_second_details_wholesale)
                .pause(2000)
                .setValue(this.selector.combination_second_details_wholesale, standard_product.standard.variations.variation2.wholesale)
                .waitForExist(this.selector.combination_second_details_priceTI, 60000)
                .click(this.selector.combination_second_details_priceTI)
                .pause(2000)
                .setValue(this.selector.combination_second_details_priceTI, standard_product.standard.variations.variation2.priceTI)
                .waitForExist(this.selector.combination_second_details_unity, 60000)
                .click(this.selector.combination_second_details_unity)
                .pause(2000)
                .setValue(this.selector.combination_second_details_unity, standard_product.standard.variations.variation2.unity)
                .waitForExist(this.selector.combination_second_details_weight, 60000)
                .click(this.selector.combination_second_details_weight)
                .pause(2000)
                .setValue(this.selector.combination_second_details_weight, standard_product.standard.variations.variation2.weight)
                .waitForExist(this.selector.combination_second_details_ISBN_code, 60000)
                .click(this.selector.combination_second_details_ISBN_code)
                .pause(2000)
                .setValue(this.selector.combination_second_details_ISBN_code, standard_product.standard.variations.variation2.isbn)
                .waitForExist(this.selector.combination_second_details_EAN13, 60000)
                .click(this.selector.combination_second_details_EAN13)
                .pause(2000)
                .setValue(this.selector.combination_second_details_EAN13, standard_product.standard.variations.variation2.ean13)
                .waitForExist(this.selector.combination_second_details_UPC, 60000)
                .click(this.selector.combination_second_details_UPC)
                .pause(2000)
                .setValue(this.selector.combination_second_details_UPC, standard_product.standard.variations.variation2.upc)
                .call(done);
        });

        it('should click on back to product button', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_second_details_back_to_product_btn, 60000)
                .click(this.selector.combination_second_details_back_to_product_btn)
                .pause(3000)
                .call(done);
        });

        it('should select the availability preferences ', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(0, 600)
                .waitForExist(this.selector.combination_availability_preferences, 90000)
                .click(this.selector.combination_availability_preferences)
                .pause(2000)
                .call(done);
        });

        it('should enter the available label in stock ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_label_in_stock, 90000)
                .click(this.selector.combination_label_in_stock)
                .pause(2000)
                .setValue(this.selector.combination_label_in_stock, standard_product.common.qty_msg_stock)
                .pause(2000)
                .call(done);
        });

        it('should enter the available label out of stock ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.combination_label_out_stock, 90000)
                .click(this.selector.combination_label_out_stock)
                .pause(2000)
                .setValue(this.selector.combination_label_out_stock, standard_product.common.qty_msg_unstock)
                .pause(2000)
                .call(done);
        });

        it('should save and stay in the product page', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.save_product_btn, 60000)
                .click(this.selector.save_product_btn)
                .pause(3000)
                .call(done);
        });
    });

    describe('Create product shipping', function (done) {
        it('should go to the product shipping form ', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(800, 0)
                .waitForExist(this.selector.product_shipping_tab, 90000)
                .click(this.selector.product_shipping_tab)
                .call(done);
        });

        it('should enter the shipping width ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.shipping_width, 90000)
                .click(this.selector.shipping_width)
                .pause(2000)
                .setValue(this.selector.shipping_width, standard_product.common.cwidth)
                .call(done);
        });

        it('should enter the shipping height ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.shipping_height, 90000)
                .click(this.selector.shipping_height)
                .pause(2000)
                .setValue(this.selector.shipping_height, standard_product.common.cheight)
                .call(done);
        });

        it('should enter the shipping depth ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.shipping_depth, 90000)
                .click(this.selector.shipping_depth)
                .pause(2000)
                .setValue(this.selector.shipping_depth, standard_product.common.cdepth)
                .call(done);
        });

        it('should enter the shipping weight ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.shipping_weight, 90000)
                .click(this.selector.shipping_weight)
                .pause(2000)
                .setValue(this.selector.shipping_weight, standard_product.common.cweight)
                .call(done);
        });

        it('should enter the additional shipping costs ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.shipping_fees, 90000)
                .click(this.selector.shipping_fees)
                .pause(2000)
                .setValue(this.selector.shipping_fees, standard_product.common.cadd_ship_coast)
                .call(done);
        });

        it('should select the available carrier ', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(this.selector.shipping_available_carriers)
                .waitForExist(this.selector.shipping_available_carriers, 90000)
                .click(this.selector.shipping_available_carriers)
                .pause(2000)
                .call(done);
        });

        it('should save and stay in the product page', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.save_product_btn, 60000)
                .click(this.selector.save_product_btn)
                .pause(3000)
                .call(done);
        });
    });

    describe('Edit product pricing', function (done) {
        it('should go to the product pricing form ', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(0, 0)
                .waitForExist(this.selector.product_pricing_tab, 90000)
                .click(this.selector.product_pricing_tab)
                .call(done);
        });

        it('should enter the pricing unity', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.pricing_unity, 60000)
                .execute(function () {
                    document.querySelector("#form_step2_unity").value = "";
                })
                .setValue(this.selector.pricing_unity, standard_product.common.unity)
                .call(done);
        });

        it('should enter the pricing tax rule', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.pricing_tax_rule_select, 60000)
                .click(this.selector.pricing_tax_rule_select)
                .pause(2000)
                .waitForExist(this.selector.pricing_tax_rule_option, 60000)
                .click(this.selector.pricing_tax_rule_option)
                .pause(2000)
                .call(done);
        });

        it('should enter the pricing wholesale', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.pricing_wholesale, 60000)
                .click(this.selector.pricing_wholesale)
                .pause(2000)
                .setValue(this.selector.pricing_wholesale, standard_product.common.wholesale)
                .call(done);
        });

        it('should select the pricing priorities', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(0, 250)
                .waitForExist(this.selector.pricing_first_priorities_select, 60000)
                .click(this.selector.pricing_first_priorities_select)
                .pause(2000)

                .waitForExist(this.selector.pricing_first_priorities_option, 60000)
                .click(this.selector.pricing_first_priorities_option)
                .pause(2000)
                .waitForExist(this.selector.pricing_second_priorities_select, 60000)
                .click(this.selector.pricing_second_priorities_select)
                .pause(2000)
                .waitForExist(this.selector.pricing_second_priorities_option, 60000)
                .click(this.selector.pricing_second_priorities_option)
                .pause(2000)
                .waitForExist(this.selector.pricing_third_priorities_select, 60000)
                .click(this.selector.pricing_third_priorities_select)
                .pause(2000)
                .waitForExist(this.selector.pricing_third_priorities_option, 60000)
                .click(this.selector.pricing_third_priorities_option)
                .pause(2000)
                .waitForExist(this.selector.pricing_foreth_priorities_select, 60000)
                .click(this.selector.pricing_foreth_priorities_select)
                .pause(2000)
                .waitForExist(this.selector.pricing_foreth_priorities_option, 60000)
                .click(this.selector.pricing_foreth_priorities_option)
                .pause(2000)
                .call(done);
        });

        it('should save and stay in the product page', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.save_product_btn, 60000)
                .click(this.selector.save_product_btn)
                .pause(3000)
                .call(done);
        });
    });

    describe('Edit the search engine optimization', function (done) {
        it('should go to the product SEO form ', function (done) {
            global.fctname = this.test.title;
            this.client
                .scroll(800, 0)
                .waitForExist(this.selector.product_SEO_tab, 90000)
                .click(this.selector.product_SEO_tab)
                .call(done);
        });

        it('should enter the meta title ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.SEO_meta_title, 90000)
                .click(this.selector.SEO_meta_title)
                .pause(2000)
                .setValue(this.selector.SEO_meta_title, standard_product.common.metatitle)
                .call(done);
        });

        it('should enter the meta description ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.SEO_meta_description, 90000)
                .click(this.selector.SEO_meta_description)
                .pause(2000)
                .setValue(this.selector.SEO_meta_description, standard_product.common.metadesc)
                .call(done);
        });

        it('should enter the friendly url ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.SEO_friendly_url, 90000)
                .click(this.selector.SEO_friendly_url)
                .pause(2000)
                .setValue(this.selector.SEO_friendly_url, standard_product.common.shortlink)
                .call(done);
        });

        it('should save and stay in the product page', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.save_product_btn, 60000)
                .click(this.selector.save_product_btn)
                .pause(3000)
                .call(done);
        });
    });

    describe('Edit the product options', function (done) {
        it('should go to the product options form ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.product_options_tab, 90000)
                .click(this.selector.product_options_tab)
                .call(done);
        });

        it('should select the visibility ', function (done) {
            global.fctname = this.test.title;
            this.client
                .waitForExist(this.selector.options_visibility, 90000)
                .click(this.selector.options_visibility)
                .pause(2000)
                .waitForExist(this.selector.options_visibility_option, 90000)
                .click(this.selector.options_visibility_option)
                .pause(2000)
                .call(done);
        });

    it('should enable the web only visibility ', function (done) {
        global.fctname = this.test.title;
        this.client
            .waitForExist(this.selector.options_online_only, 90000)
            .click(this.selector.options_online_only)
            .call(done);
    });

    it('should select condition ', function (done) {
        global.fctname = this.test.title;
        this.client
            .waitForExist(this.selector.options_condition_select, 90000)
            .click(this.selector.options_condition_select)
            .pause(2000)
            .waitForExist(this.selector.options_condition_option, 90000)
            .click(this.selector.options_condition_option)
            .call(done);
    });

    it('should enter the ISBN ', function (done) {
        global.fctname = this.test.title;
        this.client
            .waitForExist(this.selector.options_isbn, 90000)
            .click(this.selector.options_isbn)
            .pause(2000)
            .setValue(this.selector.options_isbn, standard_product.common.isbn)
            .call(done);
    });


    it('should enter the EAN-13 ', function (done) {
        global.fctname = this.test.title;
        this.client
            .waitForExist(this.selector.options_ean13, 90000)
            .click(this.selector.options_ean13)
            .pause(2000)
            .setValue(this.selector.options_ean13, standard_product.common.ean13)
            .call(done);
    });

    it('should enter the UPC ', function (done) {
        global.fctname = this.test.title;
        this.client
            .scroll(0.600)
            .pause(5000)
            .waitForExist(this.selector.options_upc, 90000)
            .setValue(this.selector.options_upc, standard_product.common.upc)
            .call(done);
    });

    it('should click on customization button ', function (done) {
        global.fctname = this.test.title;
        this.client
            .scroll(0, 600)
            .waitForExist(this.selector.options_add_customization_field_button, 90000)
            .click(this.selector.options_add_customization_field_button)
            .pause(2000)
            .call(done);
    });

    it('should create new custom field ', function (done) {
        global.fctname = this.test.title;
        this.client
            .waitForExist(this.selector.options_first_custom_field_label, 90000)
            .click(this.selector.options_first_custom_field_label)
            .pause(2000)
            .setValue(this.selector.options_first_custom_field_label, standard_product.common.personalization.perso_text.name)
            .pause(2000)
            .waitForExist(this.selector.options_first_custom_field_type, 90000)
            .selectByValue(this.selector.options_first_custom_field_type, 1)
            .pause(2000)
            .waitForExist(this.selector.options_first_custom_field_require, 90000)
            .click(this.selector.options_first_custom_field_require)
            .call(done);
    });

      it('should click on add customization field button ', function (done) {
          global.fctname = this.test.title;
          this.client
              .scroll(0, 400)
              .waitForExist(this.selector.options_add_customization_field_button, 90000)
              .click(this.selector.options_add_customization_field_button)
              .pause(2000)
              .call(done);
      });

      it('should create new custom field ', function (done) {
          global.fctname = this.test.title;
          this.client
              .waitForExist(this.selector.options_second_custom_field_label, 90000)
              .click(this.selector.options_second_custom_field_label)
              .pause(2000)
              .setValue(this.selector.options_second_custom_field_label, standard_product.common.personalization.perso_file.name)
              .pause(2000)
              .waitForExist(this.selector.options_second_custom_field_type, 90000)
              .selectByValue(this.selector.options_second_custom_field_type, 0)
              .call(done);
      });

      it('should click on attach new file button ', function (done) {
          global.fctname = this.test.title;
          this.client
              .scroll(0, 1200)
              .waitForExist(this.selector.options_add_new_file_button, 90000)
              .click(this.selector.options_add_new_file_button)
              .pause(2000)
              .call(done);
      });

      it('should add file ', function (done) {
          global.fctname = this.test.title;
          this.client
              .scroll(0, 1200)
              .pause(2000)
              .waitForExist(this.selector.options_select_file, 90000)
              .chooseFile(this.selector.options_select_file, newFile)
              .pause(2000)
              .call(done);
      });

      it('should enter the name and description of file ', function (done) {
          global.fctname = this.test.title;
          this.client
              .scroll(0, 1200)
              .pause(2000)
              .waitForExist(this.selector.options_file_name, 90000)
              .click(this.selector.options_file_name)
              .pause(2000)
              .setValue(this.selector.options_file_name, standard_product.common.document_attach.name)
              .pause(2000)
              .waitForExist(this.selector.options_file_description, 90000)
              .click(this.selector.options_file_description)
              .pause(2000)
              .setValue(this.selector.options_file_description, standard_product.common.document_attach.desc)
              .pause(2000)
              .call(done);
      });

      it('should select the previous added file ', function (done) {
          global.fctname = this.test.title;
          this.client
              .scroll(0, 1200)
              .moveToObject(this.selector.options_file_add_button)
              .pause(2000)
              .click(this.selector.options_file_add_button)
              .pause(2000)
              .call(done);
      });

      it('should save and stay in the product page', function (done) {
          global.fctname = this.test.title;
          this.client
              .waitForExist(this.selector.save_product_btn, 90000)
              .click(this.selector.save_product_btn)
              .pause(10000)
              .call(done);
      });

      it('should go to catalog product list ', function (done) {
          global.fctname = this.test.title;
          this.client
              .waitForExist(this.selector.go_to_catalog, 90000)
              .click(this.selector.go_to_catalog)
              .pause(9000)
              .call(done);
      });
  });

  describe('Check product ', function (done) {
      it('should check the product name ', function (done) {
          global.fctname = this.test.title;
          this.client
              .waitForExist(this.selector.catalogue_filter_by_name, 90000)
              .click(this.selector.catalogue_filter_by_name)
              .pause(4000)
              .setValue(this.selector.catalogue_filter_by_name, standard_product.standard.name + product_id)
              .pause(2000)
              .click(this.selector.ProductPage.click_outside)
              .waitForExist(this.selector.catalogue_submit_filter, 60000)
              .click(this.selector.catalogue_submit_filter)
              .pause(3000)
              .waitForExist(this.selector.catalog_product_name, 60000)
              .getText(this.selector.catalog_product_name).then(function (name) {
              should(name).be.equal(standard_product.standard.name + product_id)
          })
              .pause(2000)
              .call(done);
      });
  });

    describe('Log out in Back Office', function (done) {
        it('should log out successfully in BO', function (done) {
            global.fctname = this.test.title;
            this.client
                .signoutBO()
                .call(done);
        });
    });
});