// @TODO: fix connection yahoo in FO
scenario('Test module : "Social Connect" - YAHOO', () => {
    scenario('Connect with yahoo account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on yahoo button', () => client.clickOnYahooButton('yahoo'));
        test('should connecting with yahoo account', () => client.connectingYahooAccount());
        test('should check the connection', () => client.checkConnections('prestotests prestotests'));
    }, "modules_clients/social_connect/yahoo_client", true);
    // scenario('Check yahoo customer in Back Office', client => {
    //     test('should open the browser', () => client.open());
    //     test('should sign in', () => client.fillSignInForm());
    //     test('should access to customers page', () => client.goToCustomers());
    //     test('should filter the list of customers by email', () => client.filterListCustomerByAddressEmail("prestotests@yahoo.com"));
    //     test('should click on search button', () => client.clickOnSearchButton());
    //     test('should check yahoo customer', () => client.checkCutomer('yahoo'));
    // }, "modules_clients/social_connect/yahoo_client", true);
}, "modules_clients/social_connect/yahoo_client", true);