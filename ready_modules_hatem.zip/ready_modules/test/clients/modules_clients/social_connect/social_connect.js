const {selector} = require('../../../globals.webdriverio.js');
var CommonClient = require('../../common_client');

class SocialConnect extends CommonClient {

    ClickOnConfigurationAccountMenu(id_tab) {
        return this.client
            .waitForExist(selector.BO.ModulePageSocialConnect.Common.menu_tabs.replace("%ID", id_tab), 60000)
            .click(selector.BO.ModulePageSocialConnect.Common.menu_tabs.replace("%ID", id_tab))
    }

    waitForConfigurePage(name) {
        return this.client.waitForText(selector.BO.ModulePageSocialConnect.Common.title_page_name.replace("%NAME", name), 15000)
            .then(() => this.client.getText(selector.BO.ModulePageSocialConnect.Common.title_page_name.replace("%NAME", name)))
            .then((title) => {
                expect(title).to.have.string(name.toUpperCase())
            })
    }

    clickOnConnectButton() {
        return this.client
            .waitForExist(selector.FO.CheckoutPage.PersonalInformationSection.sign_in_button, 90000)
            .click(selector.FO.CheckoutPage.PersonalInformationSection.sign_in_button)
    }

    clickOnConnectAccountButton(name) {
        return this.client
            .waitForExist(selector.FO.CheckoutPage.PersonalInformationSection.first_logo.replace("%SOCIAL", name), 90000)
            .click(selector.FO.CheckoutPage.PersonalInformationSection.first_logo.replace("%SOCIAL", name))

            .then(() => this.client.windowHandles())
            .then(handles => this.client.switchTab(handles.value[1]))
    }

    fillAddressForm() {
        return this.client
            .waitForExist(selector.FO.CheckoutPage.AddressesSection.address_input, 90000)
            .setValue(selector.FO.CheckoutPage.AddressesSection.address_input, 'rue boulvard')

            .waitForExist(selector.FO.CheckoutPage.AddressesSection.postcode_input, 90000)
            .setValue(selector.FO.CheckoutPage.AddressesSection.postcode_input, '75005')

            .waitForExist(selector.FO.CheckoutPage.AddressesSection.city_input, 90000)
            .setValue(selector.FO.CheckoutPage.AddressesSection.city_input, 'Paris')

            //.moveToObject(selector.FO.CartSummary.step3_section, 90000)
            .scroll(selector.FO.CheckoutPage.AddressesSection.continue_addresses_button)
            .waitForExist(selector.FO.CheckoutPage.AddressesSection.continue_addresses_button, 90000)
            .click(selector.FO.CheckoutPage.AddressesSection.continue_addresses_button)
    }

    fillPaymentForm(id) {
        return this.client
            .click(selector.FO.CheckoutPage.PaymentSection.pay_by_radio_button.replace("%ID", id))
            .click(selector.FO.CheckoutPage.PaymentSection.terms_of_service_checkbox)
            .scroll(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
            .click(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
    }

    goToCustomers() {
        return this.client
            .waitForExist(selector.BO.Common.customer_settings_subtab, 90000)
            .click(selector.BO.Common.customer_settings_subtab)
            .pause(5000);
    }

    filterListCustomerByAddressEmail(email) {
        return this.client
            .waitForExist(selector.BO.CustomersPage.customer_address_email_input, 90000)
            .setValue(selector.BO.CustomersPage.customer_address_email_input, email)
            .pause(5000);
    }

    clickOnSearchButton() {
        return this.client
            .pause(3000)
            .waitForExist(selector.BO.CustomersPage.customer_search_button, 90000)
            .click(selector.BO.CustomersPage.customer_search_button)
    }

    checkCutomer(name) {
        let logo_customer_page_selector = selector.BO.ModulePageSocialConnect.Common.logo_customer_page;
        if (name === "twitter") {
            logo_customer_page_selector = logo_customer_page_selector.replace('6', '5');
        }
        return this.client
            .waitForExist(logo_customer_page_selector, 90000)
            .moveToObject(logo_customer_page_selector)

            .then(() => this.client.getAttribute(logo_customer_page_selector, 'title'))
            .then((title) => {
                expect(title.toLowerCase()).to.have.string(name.toLowerCase())
            })

            .then(() => this.client.getAttribute(logo_customer_page_selector, 'alt'))
            .then((alt) => {
                expect(alt.toLowerCase()).to.have.string(name.toLowerCase())
            })
    }

    checkConnections(user_name) {
        return this.client
            .waitForVisible(selector.FO.SocialConnect.Common.user_connected_span, 90000)
            .moveToObject(selector.FO.SocialConnect.Common.user_connected_span)
            .then(() => this.client.getText(selector.FO.SocialConnect.Common.user_connected_span))
            .then((user) => {
                expect(user).to.eql(user_name)
            })
            .pause(5000);
    }
}

module.exports = SocialConnect;

