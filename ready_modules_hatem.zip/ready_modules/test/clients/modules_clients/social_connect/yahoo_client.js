const {selector} = require('../../../globals.webdriverio.js');
const {external} = require('../../../globals.webdriverio.js');
const SocialConnect = require('./social_connect.js');

class YahooClient extends SocialConnect {

    clickOnYahooButton(name) {
        return this.client
            .waitForExist(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name), 90000)
            .click(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name))

            .then(() => this.client.windowHandles())
            .then(handles => this.client.switchTab(handles.value[1]))
            .pause(5000);
    }

    connectingYahooAccount(login = 'prestotests@yahoo.com', password = 'prestashop123') {
        return this.client
            .waitForVisible(selector.FO.SocialConnect.Yahoo.username_input, 90000)
            .setValue(selector.FO.SocialConnect.Yahoo.username_input, login)
            .click(selector.FO.SocialConnect.Yahoo.signin_button)
            .setValue(selector.FO.SocialConnect.Yahoo.password_input, password)
            .click(selector.FO.SocialConnect.Yahoo.signin_button)
            .waitForExist(selector.FO.SocialConnect.Yahoo.allow_button, 90000)
            .click(selector.FO.SocialConnect.Yahoo.allow_button)

            .then(() => this.client.windowHandles())
            .then((handles) => this.client.switchTab(handles.value[0]))
            .pause(5000);
    }

}

module.exports = YahooClient;

