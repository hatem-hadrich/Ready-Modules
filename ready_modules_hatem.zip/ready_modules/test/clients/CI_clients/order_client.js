var CommonClient = require('../common_client');
var {selector} = require('../../globals.webdriverio.js');

class OrderClient extends CommonClient {

    fillPaymentForm(id) {
        return this.client
            .waitForExistAndClick(selector.FO.CheckoutPage.PaymentSection.pay_by_radio_button.replace("%ID", id))
            .waitForExistAndClick(selector.FO.CheckoutPage.PaymentSection.terms_of_service_checkbox)
            .scroll(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
            .waitForExistAndClick(selector.FO.CheckoutPage.PaymentSection.order_with_an_obligation_to_pay_button)
    }

    waitForPaypalPage(selector, url) {
        return this.client
            .waitForExist(selector, 90000)
            .url('https://' + url)
    }
}
module.exports = OrderClient;