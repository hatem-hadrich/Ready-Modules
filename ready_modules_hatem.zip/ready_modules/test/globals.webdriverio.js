'use strict';
var common = require('./common.webdriverio');
var path = require('path');
var should = require('should');
var argv = require('minimist')(process.argv.slice(2));

global.date_time = new Date().getTime();
global.URL = argv.URL;
global.email = argv.EMAIL;
global.password = argv.PWD;

global.browser = argv.browser;
global.saucelabs = argv.SAUCELABS;
global._projectdir = path.join(__dirname, '..', '..');
global.product_id = new Date().getTime();
global.user_email = date_time + '@prestashop.com';
global.shop_name = 'shop' + date_time;
global.welcomeModal = "";

module.exports = {
    selector: {
        Tower: {
            //Signup page 1 selectors
            SignupPage1: {
                email_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[1]/input',
                password_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[3]/input',
                next_button: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/button'
            },

            //Signup page 2 selectors
            SignupPage2: {
                firstname_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[2]/input',
                lastname_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[4]/input',
                next_button: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/button'
            },

            //Signup page 3 selectors
            SignupPage3: {
                shopname_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[1]/input',
                website_input: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/div[4]/input',
                next_button: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/button'
            },

            //Signup page 4 selectors
            SignupPage4: {
                country_list: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/select[1]',
                language_list: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/select[2]',
                cgv_checkbox: '//*[@id="gtc"]',
                next_button: '//*[@id="app"]/div[2]/div[2]/div[2]/form/div/button'
            },

            //Dashboard page selectors
            DashboardPage:{
                close_modal_icon: 'i.close.icon',
                selectplan_button: '/html/body/div[1]/div[2]/div[2]/div[3]/div[1]/div[2]/div[1]/div[2]/a',
                modal_whats_next_button: '//*[@id="app"]/div[2]/div[2]/div[4]/div/div/div/div[2]/div/button',
                modal_next_button: '//*[@id="app"]/div[2]/div[2]/div[4]/div/div/div/div[2]/div/button',
                modal_go_to_my_account_button: '//*[@id="app"]/div[2]/div[2]/div[4]/div/div/div/div[2]/div/button',
                upgrade_plan_button: '//*[@id="app"]/div[2]/div[2]/div[3]/div[1]/div[2]/div/div[3]/a',
                manage_my_story_button: '//*[@id="app"]/div[2]/div[2]/div[1]/div[1]/div[2]/div/div/a[1]',

                shippment_config_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[1]/h5',
                get_upela_account_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[4]/button[1]',
                password_input: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[3]/form/div[1]/div[1]/input',
                signup_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[3]/form/div[2]/div[2]/button',
                modal_account_validation: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[4]/div/div',
                modal_account_validation_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[4]/div/div/div/div/button',
                configure_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[5]/div[2]/div/div/div[3]/a',

                payment_config_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[3]/div[1]/h5',
                get_paypal_account_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[3]/div[2]/div/div/div[4]/div/button',
                configure_payment_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[1]/div/div[2]/div/div[3]/div[2]/div/div/div[3]/div/button'
            },

            //Offers page selectors
            OffersPage: {
                select_button: '//*[@id="app"]/div[2]/div[2]/div[2]/div[2]/div/div[2]/div/button'
            },

            //Subscription page 1 selectors
            SubscriptionPage1: {
                mobilephone_input: '/html/body/div[1]/div[2]/div[2]/div[2]/form/div[4]/div[1]/input',
                next_button: '/html/body/div[1]/div[2]/div[2]/div[2]/form/div[6]/button'
            },

            //Subscription page 1 selectors
            SubscriptionPage2: {
                companyname_input: '#company_name',
                address_input: '#address',
                zipcode_input: '#zip_code',
                city_input: '#city',
                next_button: '/html/body/div[1]/div[2]/div[2]/div[2]/form/div[7]/div/button'
            },

            //Subscription page 3 selectors
            SubscriptionPage3: {
                creditcard_input: '#cardNumber input',
                expdate_input: '#cardExpiry input',
                secucode_input: '#cardCvc input',
                agree_checkbox: '#gtc',
                subscribenow_button: '/html/body/div[1]/div[2]/div[2]/div[2]/form/button'
            }
        },

        //Back office selectors
        BO: {

            //Common selectors
            Common: {
                menu: '#nav-sidebar',
                catalog_subtab: '#subtab-AdminCatalog',
                categories_subtab: '//*[@id="collapse-9"]/li[2]/a',
                //products_subtab: '#subtab-AdminProducts',
                products_subtab: '//*[@id="collapse-9"]/li[1]/a',
                customer_subtab: '#subtab-AdminParentCustomer',
                customer_settings_subtab: '#subtab-AdminCustomers',
                //customer_settings_subtab:'/html/body/nav/ul/li[5]/a',
                addresses_subtab: '#subtab-AdminAddresses',
                modules_subtub: '#subtab-AdminParentModulesSf',
                //modules_subtub: '/html/body/nav/ul/li[9]/a',
                orders_settings_button: '#subtab-AdminParentOrders',
                close_validation_button: '.growl-close',
                red_validation_notice: '[class="growl growl-error growl-medium"]',
                green_validation_notice: '[class="growl growl-notice growl-medium"]',
                design_button: '#subtab-AdminParentThemes',
                pages_button: '#subtab-AdminCmsContent',
                success_alert: '//*[@id="content"]/div[@class="bootstrap"]/div[contains(@class, "success")]',
                welcome_modal_later_button: '/html/body/div[1]/div/div/div[3]/button[1]',
                shopname_link: '#header_shopname',
                profile: '//*[@id="employee_infos"]',
                logout: '//*[@id="header_logout"]'
            },

            //Login page selectors
            LoginPage: {
                login_input: '#email',
                password_input: '#passwd',
                login_button: '[name="submitLogin"]'
            },

            //Modules page selectors
            ModulesPage: {
                installed_module_tabs: '(//div[@class="page-head-tabs"]/a)[2]',
                modules_search_results: '.module-search-result-wording',
                modules_search_input: '.pstaggerAddTagInput.module-tags-input',
                modules_search_button: '//div[@class="input-group module-search-block"]/button[@class="btn btn-primary pull-right search-button"]',
                installed_modules_number_span: '//*[@id="main-div"]/div[3]/div[2]/div/div[2]/div/div[7]/span[1]',
                installed_built_modules_number_span: '//*[@id="main-div"]/div[3]/div[2]/div/div[2]/div/div[9]/span[1]',
                installed_theme_modules_number_span: '//*[@id="main-div"]/div[3]/div[2]/div/div[2]/div/div[11]/span[1]',
                page_loaded: '.module-search-result-wording',
                module_menu_button: '[class="btn btn-primary-outline  dropdown-toggle"]',
                configure_module_button: '[data-confirm_modal="module-modal-confirm-%module_tech_name-configure"]',
                enable_module_button: '[data-confirm_modal="module-modal-confirm-%module_tech_name-enable"]',
                disable_module_button: '[data-confirm_modal="module-modal-confirm-%module_tech_name-disable"]',
                disable_module_confirm_button: '[class="btn btn-primary uppercase module_action_modal_disable"]',
                actions_module_dropdown: '//*[@class="btn btn-primary-outline  dropdown-toggle"]',
                action_module_installed_button: '//*[@id="modules-list-container-all"]/div[1]/div/div/div[5]/div[2]/form/button',
                action_module_built_button: '//*[@id="modules-list-container-native"]/div/div/div/div[5]/div[2]/form/button',
                action_module_theme_button: '//*[@id="modules-list-container-theme"]/div/div/div/div[5]/div[2]/form/button'
            },

            //Module page configuration selectors
            ModuleConfiguration: {
                //SEOimage module configuration page
                optimize_images_tab: '//*[@id="modulecontent"]/div[1]/div[1]/a[2]',
                add_new_rule_button: '.process-icon-new',
                rule_name_input: '//*[@id="rule_name"]',
                ruleLanguage_dropdownlist: '//*[@id="step-1"]/div[3]/div/div[1]/button',
                ruleLanguage_select: '//*[@id="step-1"]/div[3]/div/div[1]/div/ul/li[%s]',
                next_step_rule_button: '//*[@id="next-step"]',
                all_category_radio_button: '//*[@id="radios-0"]/label/input',
                category_radio_button: '//*[@id="radios-1"]/label/input',
                legend_input: '//*[@id="legend"]',
                save_rule_button: '//*[@id="btn-save"]',
                green_validation_notice: '/html/body/div[6]/div/div/div[1]/div/div[2]/button',
                apply_rule_button: '//*[@id="table-metas-1"]/tbody/tr[%s]/td[7]/div/div/a',
                apply_second_rule_button: '//*[@id="table-metas-1"]/tbody/tr[2]/td[7]/div/div/a',
                apply_all_rules_button: '//*[@id="table-metas-1"]/a[1]',
                dropdown_button: '//*[@id="table-metas-1"]/tbody/tr[1]/td[7]/div/div/button',
                edit_rule_button: '//*[@id="table-metas-1"]/tbody/tr[1]/td[7]/div/div/ul/li[1]/a',
                expan_all_button: '//*[@id="expandall"]',
                evening_dresses_checkbox: '//*[@id="category_10"]/a/i[1]',
                blouses_category_checkbox: '//*[@id="category_7"]/a/i[1]',

                //Prestafraud module configuration page
                trust_account_on_radio_button: '//*[@id="trust_account_on"]',
                email_input: '//*[@name="email"]',
                agree_checkbox: '//*[@id="terms_and_conditions"]',
                create_account_button: '//*[@id="submitCreateAccount"]',
                trust_account_off_radio_button: '//*[@id="trust_account_off"]',
                save_button: '//*[@id="prestashop_trust"]/center/input',

                //Mainmenu module configuration page
                items_optgroup: '//*[@id="availableItems"]/optgroup[4]',
                add_button: '#addItem',
                processs_icon_save: '#module_form_submit_btn'

            },

            //Orders page selectors
            OrdersPage: {
                add_new_order_button: '[id="page-header-desc-order-new_order"]',
                id_input: '//*[@id="form-order"]/div/div[2]/table/thead/tr[2]/th[2]/input',
                search_button: '//*[@id="submitFilterButtonorder"]',
                first_order_select: '//*[@id="form-order"]/div/div[2]/table/tbody/tr/td[2]'
            },

            //Order page selectors
            OrderPage: {
                order_reference_label: '//div[@class="col-lg-7"]/div[1]/div[1]/span[1]',
                order_status_dropdown: '//*[@id="id_order_state_chosen"]/a',
                order_status_from_list: '//*[@id="id_order_state_chosen"]/div/ul/li[text()="%s"]',
                update_status_button: '//*[@id="status"]/form/div/div[2]/button',
                view_invoice_button: '[data-selenium-id="view_invoice"]',
                documents_tab: '//a[@href="#documents"]',
                invoice_number_link: '//tr[td[contains(text(), \'Invoice\')]]//td/a[@title="See the document"]',
                prestashop_security_notification: '//*[@id="content"]/div[6]/div/fieldset'
            },

            ProductsPage: {
                new_product_button: '#page-header-desc-configuration-add',
                catalogue_filter_by_name: '//input[@name="filter_column_name"]',
                click_outside: '//*[@id="product_catalog_list"]/div[2]/div/table/thead/tr[1]/th[3]',
                product_apply_button: '//*[@id="product_catalog_list"]/div[2]/div/table/thead/tr[2]/th[9]/button[1]',
                first_product: '//*[@id="product_catalog_list"]/div[2]/div/table/tbody/tr[1]/td[3]/a'
            },

            ProductPage: {
                name_input_en: '#form_step1_name_2',
                name_input_fr: '#form_step1_name_1',
                language_button: '#select2-form_switch_language-container',
                language_option: '//*[@id="select2-form_switch_language-results"]/li[%ID]',
                picture: '.dz-hidden-input',
                cover_picture: '.iscover',
                picture_preview: '//*[@id="product-images-dropzone"]/div[4]',
                quantity_shortcut_input: '#form_step1_qty_0_shortcut',
                price_te_shortcut_input: '#form_step1_price_shortcut',
                category_search_input: '#ps-select-product-category',
                category_search_result: '/html/body/ul/li/a',
                online_toggle: '.switch-input ',
                validation_message: '//*[@id="growls"]/div/div[3]'
            },

            CustomersPage: {
                new_customer_button: '//*[@id="page-header-desc-customer-new_customer"]',
                customer_address_email_input: '//*[@id="form-customer"]/div/div[2]/table/thead/tr[2]/th[7]/input',
                customer_search_button: '#submitFilterButtoncustomer'
            },

            //Pages page selectors
            PagesPage: {
                pages_search_input: '//*[@id="table-cms"]/thead/tr[2]/th[4]/input',
                search_button: '//*[@id="submitFilterButtoncms"]',
                edit_page_button: '//*[@id="tr_1_3_2"]/td[7]/div/div/a'
            },

            //Page selectors
            PagePage: {
                title_input: '//*[@id="name_1"]',
                language_dropdownlist: '//*[@id="fieldset_0"]/div[2]/div[2]/div/div/div[2]/div[2]/button',
                french_language_button: '//*[@id="fieldset_0"]/div[2]/div[2]/div/div/div[2]/div[2]/ul/li[1]/a',
                save_button: '//*[@id="cms_form_submit_btn"]'
            },

            //Google Adwords module configuration page
            ModuleGoogleAdwords: {
                voucher_input: '//pre[@id="adwords_voucher"]',
                gadwords_start_button: '//*[@id="content"]/div[5]/div[2]/div/div/div/p/a'
            },
            
            //Cookie banner module configuration page
            ModulePageCookieBanner: {
                banner_position_top: '//*[@class="radio-banner-position"]/ul/li[1]',
                banner_position_bottom: '//*[@class="radio-banner-position"]/ul/li[2]',
                banner_position_bottomright: '//*[@class="radio-banner-position"]/ul/li[3]',
                banner_position_bottomleft: '//*[@class="radio-banner-position"]/ul/li[4]',
                save_button: '//*[@id="submitCookieBannerModule"]',
                background_color_input: '//*[@id="color_0"]',
                color_text_input: '//*[@id="color_3"]',
                text_textarea: 'textarea.CB-TEXT',
                text_learn_more_input: 'input.CB-LINK-TEXT',
                cms_page_select: '//*[@id="CB-CMS"]',
                accept_button_text_input: 'input.CB-BUTTON-TEXT',
                background_button_color_input: '//*[@id="color_2"]',
                on_mouse_over_input: '//*[@id="color_4"]',
                button_text_color_input: '//*[@id="color_5"]'
            },

            //Social connect module configuration page
            ModulePageSocialConnect: {
                Common: {
                    menu_tabs: '//*[@id="navtabs16"]/li[%ID]/a',
                    title_page_name: '//*[@id="%NAME"]/form/div/div[1]',
                    developers_link: '//*[@id="%NAME"]/div/div/fieldset/div[3]/a',
                    logo_customer_page: '//*[@id="form-customer"]/div/div[2]/table/tbody/tr/td[6]/img',
                },
                //@TODO
                Facebook: {
                    site_url_input: '//*[@id="facebook"]/div/div/fieldset/div[8]/input',
                    customer_key_input: '//*[@id="appid"]',
                    customer_secret_input: '//*[@id="secret"]',
                    save_button: '//*[@id="module_form_submit_btn_18"]'
                },
                Twitter: {
                    website_field_input: '//*[@id="twitter"]/div/div/fieldset/div[8]/input',
                    callback_field_input: '//*[@id="twitter"]/div/div/fieldset/div[9]/input',
                    customer_key_input: '//*[@id="twitterconskey"]',
                    customer_secret_input: '//*[@id="twitterconssecret"]',
                    save_button: '//*[@id="module_form_submit_btn_19"]'
                },
                //@TODO
                Amazon: {
                    privacy_notice_url_input: '//*[@id="amazon"]/div/div/fieldset/div[7]/input',
                    allowed_javaScript_origins_input: '//*[@id="amazon"]/div/div/fieldset/div[11]/input',
                    allowed_return_urls_input: '//*[@id="amazon"]/div/div/fieldset/div[12]/input',

                    customer_id_input: '//*[@id="aci"]',
                    return_url_input: '//*[@id="aru"]',
                    save_button: '//*[@id="module_form_submit_btn_20"]'
                },
                Google: {
                    authorized_javaScript_origins_input: '//*[@id="google"]/div/div/fieldset/div[21]/input',
                    authorized_redirect_uri_input: '//*[@id="google"]/div/div/fieldset/div[22]/input',
                    customer_key_input: '//*[@id="oci"]',
                    customer_secret_input: '//*[@id="ocs"]',
                    save_button: '//*[@id="module_form_submit_btn_21"]'
                },
                Pinterest: {
                    site_url_input: '//*[@id="pinterest"]/div/div/fieldset/div[8]/input',
                    redirect_url_input: '//*[@id="pinterest"]/div/div/fieldset/div[9]/input',
                    customer_key_input: '//*[@id="pici"]',
                    customer_secret_input: '//*[@id="pics"]',
                    save_button: '//*[@id="module_form_submit_btn_32"]'
                },
                Yahoo: {},
                Paypal: {
                    return_url_input: '//*[@id="paypal"]/div/div/fieldset/div[8]/input',
                    privacy_policy_url_input: '//*[@id="paypal"]/div/div/fieldset/div[11]/input',
                    user_agreement_url_input: '//*[@id="paypal"]/div/div/fieldset/div[12]/input',
                    customer_key_input: '//*[@id="clientid"]',
                    customer_secret_input: '//*[@id="psecret"]',
                    save_button: '//*[@id="module_form_submit_btn_23"]'
                },
                Linkedin: {
                    website_url_input: '//*[@id="linkedin"]/div/div/fieldset/div[11]/input',
                    customer_key_input: '//*[@id="lapikey"]',
                    customer_secret_input: '//*[@id="lsecret"]',
                    save_button: '//*[@id="module_form_submit_btn_24"]'
                },
                Microsoft: {
                    redirect_url_input: '//*[@id="hotmail"]/div/div/fieldset/div[8]/input',
                    customer_key_input: '//*[@id="mclientid"]',
                    customer_secret_input: '//*[@id="mclientsecret"]',
                    save_button: '//*[@id="module_form_submit_btn_25"]'
                },
                Foursquare: {
                    redirect_url_input: '//*[@id="foursquare"]/div/div/fieldset/div[9]/input',
                    welcome_page_url_input: '//*[@id="foursquare"]/div/div/fieldset/div[7]/input',
                    privacy_policy_url_input: '//*[@id="foursquare"]/div/div/fieldset/div[8]/input',
                    customer_key_input: '//*[@id="fsci"]',
                    customer_secret_input: '//*[@id="fscs"]',
                    save_button: '//*[@id="module_form_submit_btn_26"]'
                },
                Github: {
                    logo_customer_page: '//*[@id="form-customer"]/div/div[2]/table/tbody/tr/td[6]/img',
                    config_button: '//*[@id="navtabs16"]/li[13]/a',
                    developers_link: '//*[@id="github"]/div/div/fieldset/div[3]/a',
                    home_page_url_input: '//*[@id="github"]/div/div/fieldset/div[5]/input',
                    callback_url_input: '//*[@id="github"]/div/div/fieldset/div[7]/input',
                    customer_key_input: '//*[@id="gici"]',
                    customer_secret_input: '//*[@id="gics"]',
                    save_button: '//*[@id="module_form_submit_btn_27"]'
                },
                Disqus: {
                    website_url_input: '//*[@id="disqus"]/div/div/fieldset/div[8]/input',
                    callback_url_input: '//*[@id="disqus"]/div/div/fieldset/div[12]/input',
                    terms_of_service_url_input: '//*[@id="disqus"]/div/div/fieldset/div[16]/input',
                    customer_key_input: '//*[@id="dci"]',
                    customer_secret_input: '//*[@id="dcs"]',
                    save_button: '//*[@id="module_form_submit_btn_28"]'
                },
                Dropbox: {
                    redirect_uri_input: '//*[@id="dropbox"]/div/div/fieldset/div[10]/input',
                    customer_key_input: '//*[@id="dbci"]',
                    customer_secret_input: '//*[@id="dbcs"]',
                    save_button: '//*[@id="module_form_submit_btn_29"]'
                },
                Wordpress: {
                    website_url_input: '//*[@id="wordpress"]/div/div/fieldset/div[7]/input',
                    redirect_uri_input: '//*[@id="wordpress"]/div/div/fieldset/div[8]/input',
                    javascript_origins_input: '//*[@id="wordpress"]/div/div/fieldset/div[9]/input',
                    customer_key_input: '//*[@id="wci"]',
                    customer_secret_input: '//*[@id="wcs"]',
                    save_button: '//*[@id="module_form_submit_btn_30"]'
                },
                Tumblr: {
                    website_url_input: '//*[@id="tumblr"]/div/div/fieldset/div[6]/input',
                    callback_url_input: '//*[@id="tumblr"]/div/div/fieldset/div[8]/input',
                    customer_key_input: '//*[@id="tuci"]',
                    customer_secret_input: '//*[@id="tucs"]',
                    save_button: '//*[@id="module_form_submit_btn_31"]'
                },
                Vkontakte: {
                    site_address_input: '//*[@id="vkontakte"]/div/div/fieldset/div[6]/input',
                    customer_key_input: '//*[@id="vci"]',
                    customer_secret_input: '//*[@id="vcs"]',
                    save_button: '//*[@id="module_form_submit_btn_33"]'
                }
            },
        },
        FO: {
            //Common selectors
            Common: {
                language_button: '//*[@id="_desktop_language_selector"]/div/div/button',
                chooseLanguage_button: '//*[@id="_desktop_language_selector"]/div/div/ul/li[%s]/a',
                favicon: '/html/head/link[2]',
                logout: '//*[@id="_desktop_user_info"]/div/a[1]'
            },

            //Home page selectors
            HomePage: {
                logo_home_page: '//*[@id="_desktop_logo"]/a/img',
                search_input: '//*[@id="search_widget"]/form/input[2]',
                search_icon: '//*[@id="search_widget"]/form/button/i',
                sleeves_tshirt_image: '//*[@id="content"]/section/div/article[1]/div/a/img',
                blouse_image: '//*[@id="content"]/section/div/article[2]/div/a/img',
                printed_dress_casual_dresses_category_image: '//*[@id="content"]/section/div/article[3]/div/a/img',
                printed_dress_evening_dresses_category_image: '//*[@id="content"]/section/div/article[4]/div/a/img',
                first_product_home_page: '//*[@id="js-product-list"]/div[1]/article/div/a',
                sign_in_button: '//div[@class="user-info"]//span[@class="hidden-sm-down"]',
                cart_button: '//div[@id="_desktop_cart"]//a'
            },

            //Login page selectors
            LoginPage: {
                login_input: '//input[@class="form-control"]',
                password_input: '//input[@class="form-control js-child-focus js-visible-password"]',
                login_button: '//button[@class="btn btn-primary"]',
                information_block_button: '//*[@id="identity-link"]/span/i'
            },

            //Product page selectors
            ProductPage: {
                product_name: '//*[@id="main"]/div[1]/div[2]/h1',
                product_price: '//*[@id="main"]/div[1]/div[2]/div[1]/div[1]/div/span',
                product_image: '//*[@id="product-modal"]/div/div/div/figure/img',
                thumbnail_image: '//*[@id="content"]/div[1]/div[2]/ul/li[1]/img',
                category_name: '//*[@id="wrapper"]/div/nav/ol/li[4]/a/span',
                women_category_select: '//*[@id="wrapper"]/div/nav/ol/li[2]/a',
                add_to_cart_button: '.btn.btn-primary.add-to-cart',
                proceed_to_checkout_button: 'a.btn.btn-primary',
                continue_shopping_button: '[class="btn btn-secondary"]'
            },

            //Cart page selectors
            CartPage: {
                proceed_to_checkout_button: '//div[@class="checkout cart-detailed-actions card-block"]//a[@class="btn btn-primary"]'
            },

            //Checkout page selectors
            CheckoutPage: {
                PersonalInformationSection: {
                    header: '[id="checkout-personal-information-step"]',
                    order_as_a_guest_button: '//section[@id="checkout-personal-information-step"]//a[@href="#checkout-guest-form"]',
                    sign_in_button: '//section[@id="checkout-personal-information-step"]//a[@href="#checkout-login-form"]',
                    social_title_mr_radio_button: '//input[@name="id_gender" and @value="1"]',
                    social_title_mrs_radio_button: '//input[@name="id_gender" and @value="2"]',
                    first_name_input: '[name="firstname"]',
                    last_name_input: '[name="lastname"]',
                    email_guest_input: '//div[@id="checkout-guest-form"]//input[@name="email"]',
                    customer_privacy_checkbox: '[name="customer_privacy"]',
                    continue_guest_personal_information_button: '//div[@id="checkout-guest-form"]//button[@name="continue"]',
                    first_logo: '//a[@class="%SOCIAL custom-social-button-all custom-social-button-2"]'
                },
                AddressesSection: {
                    header: '[id="checkout-addresses-step"]',
                    address_input: '[name="address1"]',
                    postcode_input: '[name="postcode"]',
                    city_input: '[name="city"]',
                    country_checkbox: '//select[@name="id_country"]',
                    continue_addresses_button: '[name="confirm-addresses"]'
                },
                DeliverySection: {
                    header: '[id="checkout-delivery-step"]',
                    continue_shipping_button: '[name="confirmDeliveryOption"]'
                },
                PaymentSection: {
                    header: '[id="checkout-payment-step"]',
                    pay_by_radio_button: '[id="payment-option-%ID"]',
                    terms_of_service_checkbox: '[name="conditions_to_approve[terms-and-conditions]"]',
                    order_with_an_obligation_to_pay_button: '[class="btn btn-primary center-block"]'
                }
            },

            //Order Confirmation page selectors
            OrderConfirmationPage: {
                order_reference_label: '//*[@id="order-details"]/ul/li[1]'
            },

            //cookie banner selectors
            CookieBanner: {
                configuration_banner:'//body/div[1]',
                configuration_banner_body:'//body/div[1]/div[2]',
                configuration_banner_body_link:'//body/div[1]/div[2]/a',
                configuration_banner_body_button:'//body/div[1]/div[2]/div/button',
                page_title: '//*[@id="main"]/header/h1'
            },

            //Social connect selectors
            SocialConnect: {
                Common: {
                    first_logos: '#follow-teaser > div > a.%SOCIAL.custom-social-button-all.custom-social-button-1 > i',
                    second_logos: '#_desktop_user_info > div > span > a.%SOCIAL.custom-social-button-all.custom-social-button-4 > i',
                    third_logos: '#follow-teaser-footer > div > a.%SOCIAL.custom-social-button-all.custom-social-button-1 > i',
                    user_connected_span: '//*[@id="_desktop_user_info"]/div/a[2]/span'
                },
                Facebook: {
                    username_input: '//*[@id="email"]',
                    password_input: '//*[@id="pass"]',
                    login_button: '//*[@id="loginbutton"]'
                },
                Twitter: {
                    username_input: '//*[@id="username_or_email"]',
                    password_input: '//*[@id="password"]',
                    allow_button: '//*[@id="allow"]',
                    linked_modale: '#fb-con-wrapper',
                    email_input: '//*[@id="api-email"]',
                    send_button: '//*[@id="fb-con-wrapper"]/a[3]',
                    check_sent_email: '//*[@id="fb-con-wrapper"]/p'
                },
                Amazon: {
                    username_input: '//*[@id="ap_email"]',
                    password_input: '//*[@id="ap_password"]',
                    signin_button: '//*[@id="signInSubmit"]'
                },
                Google: {
                    username_input: '//*[@id="identifierId"]',
                    identifier_next_button: '//*[@id="identifierNext"]',
                    password_input: '//input[@type="password" and @name="password"]',
                    password_next_button: '//*[@id="passwordNext"]',
                    user_link: '//*[@id="view_container"]/form/div[2]/div/div/div/ul/li[1]/div/div[1]/img'
                },
                Pinterest: {
                    username_input: '//input[@type="email" and @name="id"]',
                    password_input: '//input[@type="password" and @name="password"]',
                    login_button: '.red.SignupButton.active',
                    allow_button: '//*[@id="dialog_footer"]/button[2]',
                    email_input: '//*[@id="api-email"]',
                    send_button: '//*[@id="fb-con-wrapper"]/a[3]',
                    check_sent_email_p: '//*[@id="fb-con-wrapper"]/p'
                },
                Yahoo: {
                    username_input : '//*[@id="login-username"]',
                    signin_button : '//*[@id="login-signin"]',
                    password_input: '//*[@id="login-passwd"]',
                    allow_button : '//*[@id="agree"]'
                },
                Paypal: {
                    username_input: '//*[@id="email"]',
                    password_input: '//*[@id="password"]',
                    login_button: '//*[@id="btnLogin"]',
                    allow_button: '//*[@id="agreeConsent"]'
                },
                Linkedin: {
                    username_input: '//*[@id="session_key-oauthAuthorizeForm"]',
                    password_input: '//*[@id="session_password-oauthAuthorizeForm"]',
                    allow_button: '.allow.btn-primary'
                },
                Microsoft: {
                    username_input: '//*[@id="i0116"]',
                    password_input: '//*[@id="i0118"]',
                    next_button: '//*[@id="idSIButton9"]',
                    accept_button: '//*[@id="idBtn_Accept"]'
                },
                Foursquare: {
                    username_input: '//*[@id="username"]',
                    password_input: '//*[@id="password"]',
                    allow_button: '//*[@id="loginFormButton"]'
                },
                Github: {
                    username_input: '//*[@id="login_field"]',
                    password_input: '//*[@id="password"]',
                    allow_button: '.btn.btn-primary.btn-block'
                },
                Disqus: {
                    username_input: '//*[@id="username"]',
                    password_input: '//*[@id="password"]',
                    allow_button: '.btn',
                    accept_button: '.btn.main'
                },
                Dropbox: {
                    username_input: '//*[@id="regular-login-forms"]/div/form/div[1]/div[1]/div[2]/input',
                    password_input: '//*[@id="regular-login-forms"]/div/form/div[1]/div[2]/div[2]/input',
                    login_button: '.login-button.signin-button.button-primary',
                    allow_button: '.auth-button.button-primary'
                },
                Wordpress: {
                    username_input: '//*[@id="usernameOrEmail"]',
                    password_input: '//*[@id="password"]',
                    login_button: '.button.form-button.is-primary',
                    allow_button: '//*[@id="approve"]'
                },
                Tumblr: {
                    username_input: '//*[@id="signup_determine_email"]',
                    password_input: '//*[@id="signup_password"]',
                    next_button: '//*[@id="signup_forms_submit"]/span[2]',
                    login_button: '.signup_login_btn.active',
                    allow_button: '.chrome.green.allow',
                    linked_modale: '#fb-con-wrapper',
                    email_input: '//*[@id="api-email"]',
                    send_button: '//*[@id="fb-con-wrapper"]/a[3]',
                    check_sent_email_p: '//*[@id="fb-con-wrapper"]/p'
                },
                Vkontakte: {
                    username_input: '//*[@id="login_submit"]/div/div/input[6]',
                    password_input: '//*[@id="login_submit"]/div/div/input[7]',
                    login_button: '//*[@id="install_allow"]'
                }
            },
        }
    },
    //External site selectors
    external: {
        //FO
        FO: {
            GoogleAdwords: {
                google_adwords_voucher: '//*[@id="right-content"]',
            },

            //@TODO
            Facebook: {
                username_input: '//*[@id="email"]',
                password_input: '//*[@id="pass"]',
                signin_button: '//*[@id="loginbutton"]',
                app_link : '//*[@id="js_en"]/span',
                customer_api_key: '//*[@id="u_0_5t"]/div[1]/div/table/tbody/tr[1]/td[1]/div/div',
                show_secret_button: '//*[@id="u_0_5u"]/div/button',
                customer_api_secret: '//*[@id="u_0_5u"]/div/span',
                settings_menu: '//*[@id="u_0_a"]',
                site_url_input: '//*[@id="u_0_7i"]/input',
                save_button: '//button[@name="save_changes"]'
            },
            Twitter: {
                signein_button: '//*[@id="gaz-content-body"]/div[2]/div/a',
                signein_login_input : '//*[@id="page-container"]/div/div[1]/form/fieldset/div[1]/input',
                signein_password_input : '//*[@id="page-container"]/div/div[1]/form/fieldset/div[2]/input',
                signein_connect_input : '//*[@id="page-container"]/div/div[1]/form/div[2]/button',

                app_link : '//*[@id="gaz-content-body"]/div[3]/div/ul/li[1]/div/div[2]/h2/a',
                settings_tab : '//*[@id="gaz-content-body"]/div[2]/ul/li[2]/a',
                key_and_access_tokens_tab : '//*[@id="gaz-content-body"]/div[2]/ul/li[3]/a',
                website_url_input : '//*[@id="edit-url"]',
                callback_url_input : '//*[@id="edit-callback-url"]',
                update_settings_button : '//*[@id="edit-submit"]',
                customer_api_key: '//*[@id="gaz-content-body"]/div[3]/div/div[2]/div[1]/span[2]',
                customer_api_secret: '//*[@id="gaz-content-body"]/div[3]/div/div[2]/div[2]/span[2]'
            },
            //@TODO
            Amazon: {
                signin_to_console_button: '//*[@id="a-autoid-1"]',
                email_input: '//*[@id="ap_email"]',
                password_input: '//*[@id="ap_password"]',
                signin_button: '//*[@id="signInSubmit-input"]',

                app_link: '//*[@id="lwa-apps-list-app-amzn1.application.3d12ffd448f5474a9a5213df9ff474ff"]',
                app_id: '//*[@id="websiteClient"]/div[2]/span',
                Application: {
                    edit_button: '//*[@id="lwa-application-edit-button"]',
                    privacy_notice_url_input: '//*[@id="lwa-privacy-notice-url"]',
                    save_button: '//*[@id="applicationPost"]/div[6]/span[2]/span/'
                },
                WebsiteSettings: {
                    edit_button: '//*[@id="lwa-website-client--edit-button"]',
                    allowed_javascript_origins_input: '//*[@id="lwa-allowed-origin-list"]/li[1]/input',
                    allowed_return_urls_input: '//*[@id="lwa-redirect-url-list"]/li[1]/input',
                    save_button: '//*[@id="lwa-website-client-save-button"]'
                }
            },
            Google: {
                username_input: '//*[@id="identifierId"]',
                identifier_next_button: '//*[@id="identifierNext"]',
                password_input: '//input[@type="password" and @name="password"]',
                password_next_button: '//*[@id="passwordNext"]',

                app_link: '//*[@id="p6n-project-table"]/tbody/tr[5]/td[2]/a',
                settings_button: '//pan-platform-bar-button[@class="p6n-console-nav-button p6n-console-nav-button-container"]/button',
                api_and_services_menu: '/html/body/pan-shell/div/div[3]/pan-console-nav-panel/div[2]/md-sidenav/md-content/pan-console-nav-products-list/div/ng-transclude/div/pan-console-nav-section-item[1]/pan-console-nav-item/div/a',
                identifiants_submenu: '//*[@id="p6n-console-nav-section-flyout-menu-0"]/md-menu-item[3]/a',
                create_identifiant_button: '//div[@class="p6n-action-bar"]/ng-include/div/a',
                identifiant_customer_oauth_link: '//div[@class="p6n-dropdown-container"]/section/div/div/div[1]/div[2]',
                application_web_checkbox: '//fieldset[@class="p6n-form-fieldset ng-pristine ng-invalid ng-invalid-required"]/div[1]/div[1]/label[1]/span',
                authorized_javaScript_input: '/html/body/pan-shell/div/div[3]/div/div[1]/pan-upgrade-panel-container/div/ng-transclude/div[2]/div/div/ng-transclude/div/div[3]/md-content/div/div[2]/div/form/oauth-client-editor/div/section/div/fieldset[1]/div/div/ng-form/ul/li',
                click_outside_p: '.p6n-form-note',
                authorized_redirect_input: '/html/body/pan-shell/div/div[3]/div/div[1]/pan-upgrade-panel-container/div/ng-transclude/div[2]/div/div/ng-transclude/div/div[3]/md-content/div/div[2]/div/form/oauth-client-editor/div/section/div/fieldset[2]/div/div/ng-form/ul/li',
                create_button: '//div[@class="p6n-form-buttons"]/button',
                ok_button: '//a[@class="p6n-loading-button p6n-modal-action-button p6n-modal-action-container md-primary p6n-modal-actions-cancel-btn md-button md-ink-ripple"]',
                api_key: '//div[@class="md-dialog-content p6n-modal-content"]/span/ng-transclude/span',
                api_secret: '//div[@class="md-dialog-content p6n-modal-content"]/div/span/ng-transclude/span'
            },
            Pinterest: {
                username_input: '//input[@type="email" and @name="id"]',
                password_input: '//input[@type="password" and @name="password"]',
                login_button: '.red.SignupButton.active',

                app_link: '//*[@id="app"]/div/section/div/h2/a',
                app_id_input: '//*[@id="app"]/div/div[2]/header/div[2]/div/div[1]/input',
                app_secret_input: '//*[@id="app"]/div/div[2]/header/div[2]/div/div[2]/input',
                show_button: '.button.tiny',
                site_url_input: '//*[@id="app"]/div/div[2]/section[3]/div/div[1]/label[1]/input',
                redirect_url_input: '//*[@id="app"]/div/div[2]/section[3]/div/div[1]/label[2]/div/div/input',
                delete_redirect_url_icon: '//*[@id="app"]/div/div[2]/section[3]/div/div[1]/label[2]/div/ul/li/div/span[2]',
                save_button: '.small.primary.two.columns'
            },
            //@TODO
            Yahoo: {

            },
            Paypal: {
                username_input: '//*[@id="email"]',
                password_input: '//*[@id="password"]',
                login_button: '//*[@id="btnLogin"]',

                manage_api_button: '//*[@id="main"]/div/div[2]/div/a[3]',
                app_link: '//div[@class="content-wrapper"]/table/tbody/tr[2]/td[1]/a',
                log_into_dashboard_button: '//*[@id="header"]/div[2]/div[2]/span/div/a',
                show_secret_button: '//*[@id="credentialsLive-sb-view"]/div/div/div[2]/div[3]/div[2]/p',
                show_return_url_button: '//*[@id="returnUrls"]',
                customer_key: '//*[@id="credentials-sb"]',
                customer_secret: '//*[@id="c-table-sb"]/table/tbody/tr/td[2]',
                return_url_input: '//*[@id="oauth_return_url__1"]',
                log_in_with_paypal_checkbox: '//*[@id="capabilityForm"]/input',
                advanced_options_button: '//*[@id="capabilityForm"]/span/span',
                personnal_information_checkbox: '//*[@id="personalCheckBox"]',
                address_information_checkbox: '//*[@id="addressCheckBox"]',
                account_information_checkbox: '//*[@id="accountCheckBox"]',
                privacy_policy_url_input: '//*[@id="privacy_policy_url"]',
                user_agreement_url_input: '//*[@id="user_agreement_url"]',
                save_button: '//*[@id="saveBtn"]',
                feedback_button: '//*[@id="applications"]/main/div/article/div[2]/a'
            },
            Linkedin: {
                identify_button: '//*[@id="uno-reg-join"]/div/div/div/div[2]/div[1]/div/div/p/a',
                username_input: '//*[@id="session_key-login"]',
                password_input: '//*[@id="session_password-login"]',
                signin_button: '//*[@id="btn-primary"]',
                app_link: '//*[@id="app-bristol"]/div[2]/a',
                preferences_button: '//*[@id="filter-tablist"]/li[2]/a',
                website_url_input: '//*[@id="websiteUrl"]',
                update_button: '//*[@id="control_gen_1"]/form/ul[11]/li/p/button[1]',
                customer_key_span: '//*[@id="control_gen_1"]/form/ul[1]/li/table/tbody/tr[1]/td[2]/span',
                customer_secret_span: '//*[@id="control_gen_1"]/form/ul[1]/li/table/tbody/tr[3]/td[2]/span'
            },
            Microsoft: {
                username_input: '//*[@id="i0116"]',
                password_input: '//*[@id="i0118"]',
                next_button: '//*[@id="idSIButton9"]',

                app_link: '//*[@id="000000004C1DDC8F"]',
                customer_key_div: '//*[@id="main"]/div/section/form/div[1]/div[1]/div/div[4]/div[2]/div',
                customer_secret_td: '//table/tbody/tr[@class="ng-scope"]/td[1]',
                redirect_url_input: '//*[@id="replyUrl"]',
                add_profile_button: '//*[@id="UploadLogoBtn"]/div[1]/div[2]',
                cancel_button: '//*[@id="cancelbutton"]',
                save_button: '//button[@class="btn btn-primary" and @type="submit" and @name="AppSaveBtn"]'
            },
            Foursquare: {
                username_input: '//*[@id="username"]',
                password_input: '//*[@id="password"]',
                allow_button: '//*[@id="loginFormButton"]',

                app_link: '//*[@id="createdApps"]/div[1]/div/div[1]/h3/a',
                update_button: '//*[@id="developerDetails"]/div[1]/a[1]',
                application_uri_input: '//*[@id="applicationUri"]',
                privacy_policy_url_input: '//*[@id="privacyPolicyUri"]',
                redirect_url_input: '//*[@id="callbackUri"]',
                save_button: '//*[@id="appTextProperties"]/div/a',
                customer_key_pre: '//*[@id="developerDetails"]/div[1]/fieldset[1]/div[1]/div/pre/code',
                customer_secret_pre: '//*[@id="developerDetails"]/div[1]/fieldset[1]/div[2]/div/pre/code'
            },
            Github: {
                username_input: '//*[@id="login_field"]',
                password_input: '//*[@id="password"]',
                allow_button: '.btn.btn-primary.btn-block',

                app_link: '//*[@id="js-pjax-container"]/div[2]/div[2]/div[2]/div/div/div[2]/a',
                customer_key_dd: '//*[@id="js-pjax-container"]/div/div[2]/div[1]/div[3]/div/div/dl/dd[1]',
                customer_secret_dd: '//*[@id="js-pjax-container"]/div/div[2]/div[1]/div[3]/div/div/dl/dd[2]',
                application_url_input: '//*[@id="oauth_application_url"]',
                application_callback_url_input: '//*[@id="oauth_application_callback_url"]',
                cancel_button: '//*[@id="new_oauth_application"]/p/a',
                update_button: '//form[@class="edit_oauth_application"]/button'
            },
            Disqus: {
                username_input: '//*[@id="username-input"]',
                password_input: '//*[@id="password-input"]',
                login_button: '.button.submit',
                app_link: '//*[@id="api-account-list"]/li/h3/a',
                api_key_pre: '//*[@id="content"]/div/div[2]/div[2]/form/div[2]/div[2]/fieldset[2]/div[1]/pre',
                api_secret_pre: '//*[@id="content"]/div/div[2]/div[2]/form/div[2]/div[2]/fieldset[2]/div[2]/pre',
                settings_subtab: '//*[@id="content"]/div/div[2]/div[2]/form/div[2]/div[1]/ul/li[2]/a',
                website_input: '//*[@id="id_website"]',
                callback_input: '//*[@id="id_callback_url"]',
                terms_of_service_input: '//*[@id="id_terms_url"]',
                save_changes_button: '.button'
            },
            Dropbox: {
                username_input: '//*[@id="regular-login-forms"]/form[1]/div[1]/div[1]/div[2]/input',
                password_input: '//*[@id="regular-login-forms"]/form[1]/div[1]/div[2]/div[2]/input',
                login_button: '.login-button.button-primary',
                app_link: '//*[@id="right-content"]/div[2]/div/div[2]/div[1]/a',
                delete_redirect_uri: '//*[@id="oauth-uri-list"]/div/div/img',
                redirect_uri_input: '//*[@id="oauth-add-uri-form"]/input[3]',
                redirect_uri_add_button: '//*[@id="oauth-add-uri-form"]/input[4]',
                app_key_div: '//*[@id="config-content"]/table/tbody/tr[5]/td[2]/div',
                app_secret_div: '//*[@id="config-content"]/table/tbody/tr[6]/td[2]/div'
            },
            Wordpress: {
                username_input: '//*[@id="usernameOrEmail"]',
                password_input: '//*[@id="password"]',
                login_button: '.button.form-button.is-primary',

                app_link: '//*[@id="content"]/ul/li/div/h2/a',
                manage_settings_subtab: '//*[@id="content"]/div[2]/div[2]/ul/li[1]/a',
                customer_key_td: '//*[@id="content"]/div[3]/div[2]/table/tbody/tr[1]/td',
                customer_secret_td: '//*[@id="content"]/div[3]/div[2]/table/tbody/tr[2]/td',
                website_url_input: '//*[@id="url"]',
                redirect_uri_input: '//*[@id="redirect_uri"]',
                javascript_origins_input: '//*[@id="javascript_origins"]',
                update_button: '.button-primary'
            },
            Tumblr: {
                username_input: '//*[@id="signup_determine_email"]',
                password_input: '//*[@id="signup_password"]',
                next_button: '//*[@id="signup_forms_submit"]/span[2]',

                signin_button: '//*[@id="signup_forms_submit"]/span[6]',
                app_link: '//*[@id="dashboard_account_oauth_apps"]/div[4]/div/div/div[2]/a[2]',
                website_url_input:'//*[@id="oac_url"]',
                callback_url_input:'//*[@id="oac_default_callback_url"]',
                save_button:'//*[@id="save_button"]',
                customer_key:'//*[@id="dashboard_account_register_oauth_app"]/div[4]/div/div/span[1]',
                customer_secret:'//*[@id="secret"]',
                show_secret_button:'//*[@id="secret_toggle"]'
            },
            Vkontakte: {
                username_input: '//*[@id="email"]',
                password_input: '//*[@id="pass"]',
                signin_button: '//*[@id="login_button"]',
                my_apps_menu: '//*[@id="dev_top_apps"]',
                app_link: '//*[@id="apps_list_content"]/div/div/div[2]/div[1]/a',
                manage_button: '//*[@id="apps_list_content"]/div/div/div[4]/a',
                settings_subtab: '//*[@id="apps_nav_options"]',
                id_text: '//*[@id="app_edit_cont"]/div[2]/table[1]/tbody/tr[1]/td[2]/b',
                secret_key_input: '//*[@id="app_secret2"]',
                site_url_input: '//*[@id="app_site_url"]',
                delete_base_domain_icon: '//*[@id="apps_edit_domain_cont"]/div/div[1]/div[1]/div/a/div',
                domain_input: '//*[@id="apps_edit_domain_cont"]/div/div[1]/div[2]/input',
                save_button: '//*[@id="app_save_btn"]'
            }
        }
    }
};