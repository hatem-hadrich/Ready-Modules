var CommonClient = require('../common_client');
const {selector} = require('../../globals.webdriverio.js');
var config = require('config');

class TowerClient extends CommonClient {

    fillSignUpPage1(email = 'demo' + user_email, password = 'abcd1234') {
        return this.client
            .url(config.get('tower.url'))
            .waitAndSetValue(selector.Tower.SignupPage1.email_input, email)
            .waitAndSetValue(selector.Tower.SignupPage1.password_input, password)
            .waitForExistAndClick(selector.Tower.SignupPage1.next_button);
    }

    fillSignUpPage2() {
        return this.client
            .waitAndSetValue(selector.Tower.SignupPage2.firstname_input, 'maurice')
            .waitAndSetValue(selector.Tower.SignupPage2.lastname_input, 'martin')
            .waitForExistAndClick(selector.Tower.SignupPage2.next_button);
    }

    fillSignUpPage3() {
        return this.client
            .waitForExist(selector.Tower.SignupPage3.website_input, 60000)
            .waitAndSetValue(selector.Tower.SignupPage3.shopname_input, shop_name)
            .waitForExistAndClick(selector.Tower.SignupPage3.next_button);
    }

    fillSignUpPage4() {
        return this.client
            .waitForExist(selector.Tower.SignupPage4.country_list, 60000)
            .selectByIndex(selector.Tower.SignupPage4.country_list, 3)
            .selectByIndex(selector.Tower.SignupPage4.language_list, 2)
            .waitForExistAndClick(selector.Tower.SignupPage4.cgv_checkbox)
            .waitForExistAndClick(selector.Tower.SignupPage4.next_button);
    }

    fillSubscribePage1() {
        return this.client
            .waitAndSetValue(selector.Tower.SubscriptionPage1.mobilephone_input, '0722334455')
            .waitForExistAndClick(selector.Tower.SubscriptionPage1.next_button);
    }

    fillSubscribePage2() {
        return this.client
            .waitAndSetValue(selector.Tower.SubscriptionPage2.companyname_input, 'shop test corp.')
            .waitAndSetValue(selector.Tower.SubscriptionPage2.address_input, '22th juan street')
            .waitAndSetValue(selector.Tower.SubscriptionPage2.zipcode_input, '42222')
            .waitAndSetValue(selector.Tower.SubscriptionPage2.city_input, 'San Antonio Vega')
            .waitForExistAndClick(selector.Tower.SubscriptionPage2.next_button);
    }

    fillSubscribePage3() {
        return this.client
            .waitAndSetValue(selector.Tower.SubscriptionPage3.creditcard_input, '4242424242424242')
            .waitAndSetValue(selector.Tower.SubscriptionPage3.expdate_input, '1148')
            .waitAndSetValue(selector.Tower.SubscriptionPage3.secucode_input, '223')
            .waitForExistAndClick(selector.Tower.SubscriptionPage3.agree_checkbox)
            .waitForExistAndClick(selector.Tower.SubscriptionPage3.subscribenow_button)
            .waitForExist(selector.Tower.DashboardPage.modal_whats_next_button, 60000);
    }

}

module.exports = TowerClient;