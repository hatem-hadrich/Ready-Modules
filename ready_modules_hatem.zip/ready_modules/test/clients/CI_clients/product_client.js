var CommonClient = require('../common_client');
var {selector} = require('../../globals.webdriverio.js');

class ProductClient extends CommonClient {

    setQuantity() {
        return this.client
            .waitForExist(selector.BO.ProductPage.quantity_shortcut_input, 90000)
            .clearElement(selector.BO.ProductPage.quantity_shortcut_input)
            .addValue(selector.BO.ProductPage.quantity_shortcut_input, '50')
    }

    setPrice() {
        return this.client
            .waitForExist(selector.BO.ProductPage.price_te_shortcut_input, 90000)
            .execute(function () {
                document.querySelector('#form_step1_price_shortcut').value = '';
            })
            .setValue(selector.BO.ProductPage.price_te_shortcut_input, '20')
    }

    selectCategory(category_name) {
        return this.client
            .waitAndSetValue(selector.BO.ProductPage.category_search_input, category_name)
            .waitForVisibleAndClick(selector.BO.ProductPage.category_search_result)
    }

    searchByName(product_name) {
        return this.client
            .waitAndSetValue(selector.BO.ProductsPage.catalogue_filter_by_name, product_name)
            .waitForExistAndClick(selector.BO.ProductsPage.click_outside)
            .waitForExistAndClick(selector.BO.ProductsPage.product_apply_button)
    }

    generatePictureURL() {
        return this.client
            .waitForExist(selector.BO.ProductPage.cover_picture, 90000)
            .getAttribute(selector.BO.ProductPage.picture_preview, "data-id").then(function (text) {
                global.image_data_id = text;
                global.picture_url = "/img/p";
                for (var i = 0, len = image_data_id.length; i < len; i++) {
                    picture_url = picture_url + "/" + image_data_id[i];
                }
                picture_url = picture_url + "/" + image_data_id + '-home_default.jpg';
            })
    }

    checkPicture() {
        return this.client
            .getAttribute('div[data-id="' + image_data_id + '"] > div ', "style").then(function (text) {
                var my_picture_url_temp = text[0].split("url(\"");
                var my_picture_url = my_picture_url_temp[1].split("\")");
                var my_final_picture_url = my_picture_url[0].split("img/");
                var final_picture_url = picture_url.split("img/");
                expect(my_final_picture_url[1]).to.be.equal(final_picture_url[1]);
            })
    }
}

module.exports = ProductClient;