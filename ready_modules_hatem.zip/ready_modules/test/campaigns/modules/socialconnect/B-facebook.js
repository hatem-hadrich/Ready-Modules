// @TODO:fix creating account and configuration of Facebook
scenario(`Test facebook`, () => {
    scenario(`Configure facebook in Back Office`, client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on facebook menu tab', () => client.ClickOnConfigurationAccountMenu(4));
        test('should configuration page is shown', () => client.waitForConfigurePage('facebook'));
        test('should click on facebook developers link', () => client.clickOnDevelopersLink('facebook'));
        test('should click on sign in button', () => client.clickOnSignInButton());
        test('should log in with facebook account', () => client.fillFacebookSignInForm());
        test('should access to the application', () => client.accessToApplication());
        test('should click on settings tab', () => client.clickOnSettingsTab());
        test('should edit website url', () => client.setWebsiteUrl());
        test('should edit callback url', () => client.setCallbackUrl());
        test('should click on update settings', () => client.clickOnUpdateSettingsButton());
        test('should click on keys and access tokens tab', () => client.clickOnKeysAccessTokens());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/facebook_client", true);
    scenario('Connect with facebook account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on facebook button', () => client.clickOnFacebookButton('facebook'));
        test('should connecting with facebook account', () => client.connectingFacebookAccount());
        test('should linked the account of facebook', () => client.linkedAccount('sifast.qa@gmail.com'));
        test('should check the connection', () => client.checkConnections('sifast qa'));
    }, "modules_clients/social_connect/facebook_client", true);
    scenario('Check facebook customer in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Customer settings" page', () => client.goToSubtabMenuPage(selector.BO.Common.customer_subtab, selector.BO.Common.customer_settings_subtab));
        test('should check facebook customer', () => client.checkCutomer('facebook'));
    }, "modules_clients/social_connect/facebook_client", true);
    scenario('Buy product with facebook account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on facebook button', () => client.clickOnConnectAccountButton('facebook'));
        test('should connecting with facebook account', () => client.connectingFacebookAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/facebook_client", true);
}, "social-connect/facebook-client", true);