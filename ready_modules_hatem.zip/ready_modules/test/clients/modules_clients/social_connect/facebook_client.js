const {selector} = require('../../../globals.webdriverio.js');
const {external} = require('../../../globals.webdriverio.js');
const SocialConnect = require('./social_connect.js');

class FacebookClient extends SocialConnect {

    constructor() {
        super();
        this._websiteUrl = "";
        this._callbackUrl = "";
        this._key = "";
        this._secret = "";
    }

    get websiteUrl() {
        return this._websiteUrl;
    }

    get callbackUrl() {
        return this._callbackUrl;
    }

    get key() {
        return this._key;
    }

    get secret() {
        return this._secret;
    }

    set websiteUrl(value) {
        this._websiteUrl = value;
    }

    set callbackUrl(value) {
        this._callbackUrl = value;
    }

    set key(value) {
        this._key = value;
    }

    set secret(value) {
        this._secret = value;
    }

    clickOnDevelopersLink(name) {
        return this.client
            .waitForExist(selector.BO.ModulePageSocialConnect.Facebook.website_field_input, 90000)
            .then(() => this.client.getAttribute(selector.BO.ModulePageSocialConnect.Facebook.website_field_input, 'value'))
            .then((website) => this.websiteUrl = website)

            .waitForExist(selector.BO.ModulePageSocialConnect.Facebook.callback_field_input, 90000)
            .then(() => this.client.getAttribute(selector.BO.ModulePageSocialConnect.Facebook.callback_field_input, 'value'))
            .then((callback) => this.callbackUrl = callback)

            .waitForExist(selector.BO.ModulePageSocialConnect.Common.developers_link.replace("%NAME", name), 90000)
            .click(selector.BO.ModulePageSocialConnect.Common.developers_link.replace("%NAME", name))
            .then(() => this.client.getTabIds())
            .then(ids => this.client.switchTab(ids[1]))
            .pause(5000);
    }

    clickOnSignInButton() {
        return this.client
            .waitForExist(external.FO.Facebook.signein_button, 90000)
            .click(external.FO.Facebook.signein_button)
            .pause(5000);
    }

    fillFacebookSignInForm(login = "sifast.qa@gmail.com", password = "sifast_qa") {
        return this.client
            .waitForExist(external.FO.Facebook.signein_login_input, 90000)
            .setValue(external.FO.Facebook.signein_login_input, login)
            .setValue(external.FO.Facebook.signein_password_input, password)
            .waitForExist(external.FO.Facebook.signein_connect_input, 90000)
            .click(external.FO.Facebook.signein_connect_input)
            .pause(5000);
    }

    accessToApplication() {
        return this.client
            .waitForExist(external.FO.Facebook.app_link, 90000)
            .click(external.FO.Facebook.app_link)
            .pause(5000);
    }

    clickOnSettingsTab() {
        return this.client
            .waitForExist(external.FO.Facebook.settings_tab, 90000)
            .click(external.FO.Facebook.settings_tab)
            .pause(5000);
    }

    setWebsiteUrl() {
        return this.client
            .waitForExist(external.FO.Facebook.website_url_input, 90000)
            .setValue(external.FO.Facebook.website_url_input, this.websiteUrl)
            .pause(5000);
    }

    setCallbackUrl() {
        return this.client
            .waitForExist(external.FO.Facebook.callback_url_input, 90000)
            .setValue(external.FO.Facebook.callback_url_input, this.callbackUrl)
            .pause(5000);
    }

    clickOnUpdateSettingsButton() {
        return this.client
            .waitForExist(external.FO.Facebook.update_settings_button, 90000)
            .click(external.FO.Facebook.update_settings_button)
            .pause(5000);
    }

    clickOnKeysAccessTokens() {
        return this.client
            .waitForExist(external.FO.Facebook.key_and_access_tokens_tab, 90000)
            .click(external.FO.Facebook.key_and_access_tokens_tab)

            .waitForExist(external.FO.Facebook.customer_api_key, 90000)
            .then(() => this.client.getText(external.FO.Facebook.customer_api_key))
            .then((key) => this.key = key)

            .waitForExist(external.FO.Facebook.customer_api_secret, 90000)
            .then(() => this.client.getText(external.FO.Facebook.customer_api_secret))
            .then((secret) => this.secret = secret)

            .then(() => this.client.getTabIds())
            .then(ids => this.client.switchTab(ids[0]))
            .pause(5000);
    }

    fillConfigurationForm() {
        return this.client
            .waitForExist(selector.BO.ModulePageSocialConnect.Facebook.customer_key_input, 90000)
            .waitForExist(selector.BO.ModulePageSocialConnect.Facebook.customer_secret_input, 90000)
            .setValue(selector.BO.ModulePageSocialConnect.Facebook.customer_key_input, this.key)
            .setValue(selector.BO.ModulePageSocialConnect.Facebook.customer_secret_input, this.secret)
            .scroll(selector.BO.ModulePageSocialConnect.Facebook.save_button)
            .waitForExist(selector.BO.ModulePageSocialConnect.Facebook.save_button, 90000)
            .click(selector.BO.ModulePageSocialConnect.Facebook.save_button)
            .pause(5000);
    }

    clickOnFacebookButton(name) {
        return this.client
            .waitForExist(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name), 90000)
            .click(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name))

            .then(() => this.client.windowHandles())
            .then(handles => this.client.switchTab(handles.value[1]))
            .pause(5000);
    }

    connectingFacebookAccount(login = 'sifast.qa@gmail.com', password = 'sifast_qa') {
        return this.client
            .waitForVisible(selector.FO.SocialConnect.Facebook.username_input, 90000)
            .setValue(selector.FO.SocialConnect.Facebook.username_input, login)
            .setValue(selector.FO.SocialConnect.Facebook.password_input, password)
            .waitForExist(selector.FO.SocialConnect.Facebook.allow_button, 90000)
            .click(selector.FO.SocialConnect.Facebook.allow_button)

            .then(() => this.client.windowHandles())
            .then((handles) => this.client.switchTab(handles.value[0]))
            .pause(5000);
    }

    linkedAccount(login) {
        return this.client
            .waitForVisible(selector.FO.SocialConnect.Facebook.linked_modale, 90000)
            .setValue(selector.FO.SocialConnect.Facebook.email_input, login)
            .waitForExist(selector.FO.SocialConnect.Facebook.send_button, 90000)
            .click(selector.FO.SocialConnect.Facebook.send_button)
            .pause(3000)

            .then(() => this.client.getText(selector.FO.SocialConnect.Facebook.check_sent_email))
            .then((value) => {
                expect(value).to.eql("Password has been sent to your mailbox: " + login)
            })
            .url('https://' + URL)
            .pause(5000);
    }

}

module.exports = FacebookClient;

