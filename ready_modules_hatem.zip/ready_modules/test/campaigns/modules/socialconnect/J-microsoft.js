// @TODO: fix connecting with microsoft account in FO when we buy product(error 502 bad gatway)
const { selector } = require('../../../globals.webdriverio.js');

scenario('Test module : "Social Connect" - MICROSOFT', () => {
    scenario('Configure microsoft in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on microsoft menu tab', () => client.ClickOnConfigurationAccountMenu(11));
        test('should configuration page is shown', () => client.waitForConfigurePage("hotmail"));
        test('should click on microsoft developers link', () => client.clickOnDevelopersLink("hotmail"));
        test('should log in with microsoft account', () => client.fillMicrosoftSignInForm());
        test('should click on cancel button', () => client.clickOnCancelButton());
        test('should access to the application', () => client.accessToApplication());
        test('should edit the redirect url', () => client.setRedirectUrl());
        test('should click on save button', () => client.clickOnSaveButton());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/microsoft_client", true);
    scenario('Connect with microsoft account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on microsoft button', () => client.clickOnMicrosoftButton('microsoft'));
        test('should connecting with microsoft account', () => client.connectingMicrosoftAccount());
        test('should check the connection', () => client.checkConnections('Tests Presto'));
    }, "modules_clients/social_connect/microsoft_client", true);
    scenario('Check microsoft customer in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Customer settings" page', () => client.goToSubtabMenuPage(selector.BO.Common.customer_subtab, selector.BO.Common.customer_settings_subtab));
        test('should filter the list of customers by email', () => client.filterListCustomerByAddressEmail("prestotests@outlook.com"));
        test('should click on search button', () => client.clickOnSearchButton());
        test('should check microsoft customer', () => client.checkCutomer('microsoft'));
    }, "modules_clients/social_connect/microsoft_client", true);
    scenario('Buy product with microsoft account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on microsoft button', () => client.clickOnConnectAccountButton('microsoft'));
        test('should connecting with microsoft account', () => client.connectingMicrosoftAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/microsoft_client", true);
}, "modules_clients/social_connect/microsoft_client", true);