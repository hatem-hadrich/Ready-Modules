// @TODO: fix connecting with google account in FO when we buy product(error 502 bad gatway)
const { selector } = require('../../../globals.webdriverio.js');

scenario('Test module "Social Connect" - google', () => {
    scenario('Configure google in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on twitter menu tab', () => client.ClickOnConfigurationAccountMenu(7));
        test('should configuration page is shown', () => client.waitForConfigurePage('google'));
        test('should click on google developers link', () => client.clickOnDevelopersLink('google'));
        test('should log in with google account', () => client.fillGoogleSignInForm());
        test('should access to the application', () => client.accessToApplication());
        test('should go to identifiants menu', () => client.clickOnIdentifiantsMenu());
        test('should click on create identifiants button', () => client.clickOnCreateIdentifiantButton());
        test('should click on oauth', () => client.clickOnOauthButton());
        test('should select a web application', () => client.selectTypeApplication());
        test('should edit authorized javaScript origins', () => client.setJavaScriptOrigins());
        test('should edit authorized redirect uri', () => client.setAuthorizedRedirectUri());
        test('should click on create button', () => client.clickOnCreateButton());
        test('should click on ok button', () => client.clickOnOkButton());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/google_client", true);
    scenario('Connect with google account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on google button', () => client.clickOnGoogleButton('google'));
        test('should connecting with google account', () => client.connectingGoogleAccount());
        test('should check the connection', () => client.checkConnections('Presto Tests'));
    }, "modules_clients/social_connect/google_client", true);
    scenario('Check google customer in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should access to customers page', () => client.goToCustomers());
        test('should filter the list of customers by email', () => client.filterListCustomerByAddressEmail("prestotests@gmail.com"));
        test('should click on search button', () => client.clickOnSearchButton());
        test('should check google customer', () => client.checkCutomer('google'));
    }, "modules_clients/social_connect/google_client", true);
    scenario('Buy product with google account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on twitter button', () => client.clickOnConnectAccountButton('google'));
        test('should connecting with twitter account', () => client.connectingTwitterAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/google_client", true);
}, "modules_clients/social_connect/google_client", true);