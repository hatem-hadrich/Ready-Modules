// @TODO: fix connecting with disqus account in FO when we buy product(error 502 bad gatway)
const { selector } = require('../../../globals.webdriverio.js');

scenario('Test module : "Social Connect" - DISQUS', () => {
    scenario('Configure disqus in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Installed modules" page', () => client.goToModulesPage());
        test('should search "fbloginblock" module', () => client.searchModule('fbloginblock'));
        test('should check that "fbloginblock" module is installed', () => client.getInstalledModulesNumber());
        test('should get the name of the first action button of the module', () => client.getModuleButtonName());
        test('should click on "Configure" button', () => client.clickConfigureModuleButton('fbloginblock'));
        test('should click on disqus menu tab', () => client.ClickOnConfigurationAccountMenu(14));
        test('should configuration page is shown', () => client.waitForConfigurePage('disqus'));
        test('should click on disqus developers link', () => client.clickOnDevelopersLink('disqus'));
        test('should log in with disqus account', () => client.fillDisqusSignInForm());
        test('should access to the application', () => client.accessToApplication());
        test('should access to the settings subtab', () => client.clickOnSettingsSubTab());
        test('should edit the website url', () => client.setWebsiteUrl());
        test('should edit the callback url', () => client.setCallbackUrl());
        test('should edit the terms of service url', () => client.setTermsOfServiceUrl());
        test('should click on save changes button', () => client.clickOnSaveChangesButton());
        test('should update configuration settings', () => client.fillConfigurationForm());
    }, "modules_clients/social_connect/disqus_client", true);
    scenario('Connect with disqus account in Front Office', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should click on disqus button', () => client.clickOnDisqusButton('disqus'));
        test('should connecting with disqus account', () => client.connectingDisqusAccount());
        test('should check the connection', () => client.checkConnections('prestotests prestotests'));
    }, "modules_clients/social_connect/disqus_client", true);
    scenario('Check disqus customer in Back Office', client => {
        test('should open the browser', () => client.open());
        test('should login successfully in BO', () => client.signInBO(selector));
        test('should go to "Customer settings" page', () => client.goToSubtabMenuPage(selector.BO.Common.customer_subtab, selector.BO.Common.customer_settings_subtab));
        test('should filter the list of customers by email', () => client.filterListCustomerByAddressEmail("prestotests+disqus@gmail.com"));
        test('should click on search button', () => client.clickOnSearchButton());
        test('should check disqus customer', () => client.checkCutomer('disqus'));
    }, "modules_clients/social_connect/disqus_client", true);
    scenario('Buy product with disqus account in FrontOffice', client => {
        test('should open the browser', () => client.open());
        test('should access to front office', () => client.openShop());
        test('should search Robe1511800819540 product', () => client.searchProduct('Robe1511800819540'));
        test('should enter to the product page', () => client.waitForExistAndClick(selector.FO.HomePage.first_product_home_page));
        test('should click on "Add to cart" button', () => client.waitForExistAndClick(selector.FO.ProductPage.add_to_cart_button));
        test('should click on "Proceed to checkout" button in "Product" page', () => client.waitForVisibleAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on "Proceed to checkout" button in "cart" page', () => client.waitForExistAndClick(selector.FO.ProductPage.proceed_to_checkout_button));
        test('should click on connect button', () => client.clickOnConnectButton());
        test('should click on disqus button', () => client.clickOnConnectAccountButton('disqus'));
        test('should connecting with disqus account', () => client.connectingDisqusAccount());
        test('should select the address step-2', () => client.fillAddressForm());
        test('should fill the shipping form', () => client.waitForExistAndClick(selector.FO.CheckoutPage.DeliverySection.continue_shipping_button));
        test('should fill the payment form', () => client.fillPaymentForm(1));
        test('should get the order id', () => client.getId('id_order'));
    }, "modules_clients/social_connect/disqus_client", true);
}, "modules_clients/social_connect/disqus_client", true);