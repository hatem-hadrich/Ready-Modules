const {selector} = require('../../../globals.webdriverio.js');
const {external} = require('../../../globals.webdriverio.js');
const SocialConnect = require('./social_connect.js');

class AmazonClient extends SocialConnect {

    constructor() {
        super();
        this._privacyNoticeUrl = "";
        this._allowedJavaScriptOrigins = "";
        this._allowedReturnUrls = "";
        this._key = "";
        this._secret = "";
    }

    get privacyNoticeUrl() {
        return this._privacyNoticeUrl;
    }

    get allowedJavaScriptOrigins() {
        return this._allowedJavaScriptOrigins;
    }

    get allowedReturnUrls() {
        return this._allowedReturnUrls;
    }

    get key() {
        return this._key;
    }

    get secret() {
        return this._secret;
    }

    set privacyNoticeUrl(value) {
        this._privacyNoticeUrl = value;
    }

    set allowedJavaScriptOrigins(value) {
        this._allowedJavaScriptOrigins = value;
    }

    set allowedReturnUrls(value) {
        this._allowedReturnUrls = value;
    }

    set key(value) {
        this._key = value;
    }

    set secret(value) {
        this._secret = value;
    }

    clickOnDevelopersLink(name) {
        return this.client
            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.privacy_notice_url_input, 90000)
            .then(() => this.client.getAttribute(selector.BO.ModulePageSocialConnect.Amazon.privacy_notice_url_input, 'value'))
            .then((url) => this.privacyNoticeUrl = url)

            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.allowed_javaScript_origins_input, 90000)
            .then(() => this.client.getAttribute(selector.BO.ModulePageSocialConnect.Amazon.allowed_javaScript_origins_input, 'value'))
            .then((javaScriptOrigins) => this.allowedJavaScriptOrigins = javaScriptOrigins)

            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.allowed_return_urls_input, 90000)
            .then(() => this.client.getAttribute(selector.BO.ModulePageSocialConnect.Amazon.allowed_return_urls_input, 'value'))
            .then((url) => this.allowedReturnUrls = url)

            .waitForExist(selector.BO.ModulePageSocialConnect.Common.developers_link.replace("%NAME", name), 90000)
            .click(selector.BO.ModulePageSocialConnect.Common.developers_link.replace("%NAME", name))
            .then(() => this.client.getTabIds())
            .then(ids => this.client.switchTab(ids[1]))
    }

    fillAmazonSignInForm(login = "prestotests+amazon@gmail.com", password = "presto_tests") {
        return this.client
            .waitForExist(external.FO.Amazon.email_input, 90000)
            .setValue(external.FO.Amazon.email_input, login)
            .setValue(external.FO.Amazon.password_input, password)
            .waitForExist(external.FO.Amazon.signin_button, 90000)
            .click(external.FO.Amazon.signin_button)
    }

    accessToApplication() {
        return this.client
            .waitForExist(external.FO.Amazon.app_link, 90000)
            .click(external.FO.Amazon.app_link)
            .pause(2000)
            .waitForExist(external.FO.Amazon.app_id, 90000)
            .then(() => this.client.getText(external.FO.Amazon.app_id))
            .then((key) => this.key = key)
    }

    setApplication() {
        return this.client
            .waitForExist(external.FO.Amazon.Application.privacy_notice_url_input, 90000)
            .setValue(external.FO.Amazon.Application.privacy_notice_url_input, this.privacyNoticeUrl)
            .waitForExist(external.FO.Amazon.Application.save_button, 90000)
            .click(external.FO.Amazon.Application.save_button)
    }

    setWebsite() {
        return this.client
            .waitForExist(external.FO.Amazon.WebsiteSettings.allowed_javascript_origins_input, 90000)
            .setValue(external.FO.Amazon.WebsiteSettings.allowed_javascript_origins_input, this.allowedJavaScriptOrigins)
            .waitForExist(external.FO.Amazon.WebsiteSettings.allowed_return_urls_input, 90000)
            .setValue(external.FO.Amazon.WebsiteSettings.allowed_return_urls_input, this.allowedReturnUrls)
            .waitForExist(external.FO.Amazon.WebsiteSettings.save_button, 90000)
            .click(external.FO.Amazon.WebsiteSettings.save_button)
            .pause(2000)

            .then(() => this.client.getTabIds())
            .then(ids => this.client.switchTab(ids[0]));
    }

    fillConfigurationForm() {
        return this.client
            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.customer_id_input, 90000)
            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.return_url_input, 90000)
            .setValue(selector.BO.ModulePageSocialConnect.Amazon.customer_id_input, this.key)
            .setValue(selector.BO.ModulePageSocialConnect.Amazon.return_url_input, this.allowedReturnUrls)

            .scroll(selector.BO.ModulePageSocialConnect.Amazon.save_button)
            .waitForExist(selector.BO.ModulePageSocialConnect.Amazon.save_button, 90000)
            .click(selector.BO.ModulePageSocialConnect.Amazon.save_button)
            .pause(5000);
    }

    clickOnAmazonButton(name) {
        return this.client
            .waitForExist(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name), 90000)
            .click(selector.FO.SocialConnect.Common.first_logos.replace("%SOCIAL", name))

            .then(() => this.client.windowHandles())
            .then(handles => this.client.switchTab(handles.value[1]))
            .pause(5000);
    }

    connectingAmazonAccount(login = 'prestotests+amazon@gmail.com', password = 'presto_tests') {
        return this.client
            .waitForVisible(selector.FO.SocialConnect.Amazon.username_input, 90000)
            .setValue(selector.FO.SocialConnect.Amazon.username_input, login)
            .setValue(selector.FO.SocialConnect.Amazon.password_input, password)
            .waitForExist(selector.FO.SocialConnect.Amazon.signin_button, 90000)
            .click(selector.FO.SocialConnect.Amazon.signin_button)

            .then(() => this.client.windowHandles())
            .then((handles) => this.client.switchTab(handles.value[0]))
            .pause(5000);
    }
}

module.exports = AmazonClient;

