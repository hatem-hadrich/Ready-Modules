'use strict';
var client;
var webdriverio = require('webdriverio');
var globals = require('./globals.webdriverio');

var options = {
    logLevel: 'silent',
    waitForTimeout: 30000,
    desiredCapabilities: {
        browserName: 'chrome',
    },
    port: 4444
};

var options2 = {
    logLevel: 'silent',
    waitForTimeout: 30000,
    desiredCapabilities: {
        browserName: 'chrome',
        'tunnel-identifier': process.env.TRAVIS_JOB_NUMBER,
        username: process.env.SAUCE_USERNAME,
        access_key: process.env.SAUCE_ACCESS_KEY,
        screenResolution: "1680x1050",
        platform: "Windows 7",
    },
    port: 4445
};

function initCommands(client) {

    client.addCommand('localhost', function (cb) {
        this.selector = globals.selector;
        client
            .url('http://' + URL + 'install-dev')
            .call(cb);
    });

    client.addCommand('signinBO', function (selector) {
        return client
            .url('https://' + URL + '/backoffice/')
            .waitAndSetValue(selector.BO.LoginPage.login_input, email)
            .waitAndSetValue(selector.BO.LoginPage.password_input, password)
            .waitForExistAndClick(selector.BO.LoginPage.login_button)
            .waitForExist(selector.BO.Common.menu, 90000)
    });

    client.addCommand('signinFO', function (selector) {
        return client
            .waitForExistAndClick(selector.FO.HomePage.sign_in_button)
            .waitAndSetValue(selector.FO.LoginPage.login_input, 'pub' + user_email)
            .waitAndSetValue(selector.FO.LoginPage.password_input, '123456789')
            .waitForExistAndClick(selector.FO.LoginPage.login_button)
            .waitForExistAndClick(selector.FO.HomePage.logo_home_page)
    });

    client.addCommand('signoutBO', function (selector) {
        return client
            .waitForExistAndClick(selector.BO.Common.profile)
            .waitForExistAndClick(selector.BO.Common.logout)
            .deleteCookie()
    });

    client.addCommand('signoutFO', function (selector) {
        return client
            .waitForExistAndClick(selector.FO.Common.logout)
            .deleteCookie()
    });

    client.addCommand('waitForExistAndClick', function (selector, timeout = 90000) {
        return client
            .waitForExist(selector, timeout)
            .click(selector)
    });

    client.addCommand('waitForVisibleAndClick', function (selector, timeout = 90000) {
        return client
            .waitForVisible(selector, timeout)
            .click(selector)
    });

    client.addCommand('waitAndSetValue', function (selector, value) {
        return client
            .waitForExist(selector , 90000)
            .setValue(selector, value)
    });

    client.addCommand('switchWindow', function (id) {
        return client
            .getTabIds()
            .then(ids => client.switchTab(ids[id]))
    });

    client.addCommand('closeWindow', function (id) {
        return client
            .getTabIds()
            .then(ids => client.close(ids[id]))
    });
};

module.exports = {
    getClient: function () {
        if (client) {
            return client;
        } else {
            if (typeof saucelabs !== 'undefined' && saucelabs != "None") {
                client = webdriverio
                    .remote(options2)
                    .init()
                    .windowHandleMaximize()
            } else {
                client = webdriverio
                    .remote(options)
                    //.init()
                    .windowHandleMaximize()
            }
            initCommands(client);

            return client;
        }
    },
};