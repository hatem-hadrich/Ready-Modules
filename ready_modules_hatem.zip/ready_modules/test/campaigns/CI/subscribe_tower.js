const { selector } = require('../../globals.webdriverio.js');

module.exports = {
    subscribeOnTower: function () {
        scenario('Subscribe on Prestashop Ready', client => {
            test('should open the browser', () => client.open());
            test('should fill "Sign up" page 1 successfully', () => client.fillSignUpPage1());
            test('should fill "Sign up" page 2 successfully', () => client.fillSignUpPage2());
            test('should fill "Sign up" page 3 successfully', () => client.fillSignUpPage3());
            test('should fill "Sign up" page 4 successfully', () => client.fillSignUpPage4());
            test('should close the "Start modal"', () => client.waitForVisibleAndClick(selector.Tower.DashboardPage.close_modal_icon));
            test('should open the "Offer" page', () => client.waitForExistAndClick(selector.Tower.DashboardPage.selectplan_button));
            test('should select "Start" plan', () => client.waitForExistAndClick(selector.Tower.OffersPage.select_button));
            test('should fill "Subscribe" page 1', () => client.fillSubscribePage1());
            test('should fill "Subscribe" page 2', () => client.fillSubscribePage2());
            test('should fill "Subscribe" page 3', () => client.fillSubscribePage3());
            test('should browse carousel page 1', () => client.waitForExistAndClick(selector.Tower.DashboardPage.modal_whats_next_button));
            test('should browse carousel page 2', () => client.waitForExistAndClick(selector.Tower.DashboardPage.modal_next_button));
            test('should browse carousel page 3', () => client.waitForExistAndClick(selector.Tower.DashboardPage.modal_go_to_my_account_button));
            test('should validate the offer status', () => client.waitForExist(selector.Tower.DashboardPage.upgrade_plan_button));
        }, 'CI_clients/tower_client');
    }
}